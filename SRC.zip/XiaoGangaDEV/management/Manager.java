/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.management;

public interface Manager {
    public void init();
}

