/*
 * Decompiled with CFR 0_132.
 * 
 * Could not load the following classes:
 *  org.lwjgl.input.Keyboard
 */
package com.XiaoGangaDEV.management;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Keyboard;

import com.XiaoGangaDEV.api.EventBus;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.misc.EventKey;
import com.XiaoGangaDEV.api.events.rendering.EventRender2D;
import com.XiaoGangaDEV.api.events.rendering.EventRender3D;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.module.modules.combat.AntiBot;
import com.XiaoGangaDEV.module.modules.combat.AutoHead;
import com.XiaoGangaDEV.module.modules.combat.AutoHeal;
import com.XiaoGangaDEV.module.modules.combat.AutoSword;
import com.XiaoGangaDEV.module.modules.combat.BowAimBot;
import com.XiaoGangaDEV.module.modules.combat.CSGOAimBot;
import com.XiaoGangaDEV.module.modules.combat.Criticals;
import com.XiaoGangaDEV.module.modules.combat.FastBow;
import com.XiaoGangaDEV.module.modules.combat.KillAura;
import com.XiaoGangaDEV.module.modules.combat.NewAntiBot;
import com.XiaoGangaDEV.module.modules.combat.Regen;
import com.XiaoGangaDEV.module.modules.combat.TNTBlock;
import com.XiaoGangaDEV.module.modules.combat.TPAura;
import com.XiaoGangaDEV.module.modules.movement.Boost;
import com.XiaoGangaDEV.module.modules.movement.ClickTp;
import com.XiaoGangaDEV.module.modules.movement.Flight;
import com.XiaoGangaDEV.module.modules.movement.InvMove;
import com.XiaoGangaDEV.module.modules.movement.Jesus;
import com.XiaoGangaDEV.module.modules.movement.Longjump;
import com.XiaoGangaDEV.module.modules.movement.NewFly;
import com.XiaoGangaDEV.module.modules.movement.NewSpeed;
import com.XiaoGangaDEV.module.modules.movement.NoSlowDown;
import com.XiaoGangaDEV.module.modules.movement.Scaffold;
import com.XiaoGangaDEV.module.modules.movement.Sneak;
import com.XiaoGangaDEV.module.modules.movement.Speed;
import com.XiaoGangaDEV.module.modules.movement.Sprint;
import com.XiaoGangaDEV.module.modules.movement.Step;
import com.XiaoGangaDEV.module.modules.movement.Teleport;
import com.XiaoGangaDEV.module.modules.player.AntiAim;
import com.XiaoGangaDEV.module.modules.player.AntiFireBall;
import com.XiaoGangaDEV.module.modules.player.AntiObs;
import com.XiaoGangaDEV.module.modules.player.AntiVelocity;
import com.XiaoGangaDEV.module.modules.player.AutoAccept;
import com.XiaoGangaDEV.module.modules.player.Bobbing;
import com.XiaoGangaDEV.module.modules.player.Dab;
import com.XiaoGangaDEV.module.modules.player.Disabler;
import com.XiaoGangaDEV.module.modules.player.FastUse;
import com.XiaoGangaDEV.module.modules.player.Freecam;
import com.XiaoGangaDEV.module.modules.player.InvCleaner;
import com.XiaoGangaDEV.module.modules.player.MCF;
import com.XiaoGangaDEV.module.modules.player.NoFall;
import com.XiaoGangaDEV.module.modules.player.NoStrike;
import com.XiaoGangaDEV.module.modules.player.SkinFlash;
import com.XiaoGangaDEV.module.modules.player.Teams;
import com.XiaoGangaDEV.module.modules.player.Zoot;
import com.XiaoGangaDEV.module.modules.render.Chams;
import com.XiaoGangaDEV.module.modules.render.ChestESP;
import com.XiaoGangaDEV.module.modules.render.ClickGui;
import com.XiaoGangaDEV.module.modules.render.ESP;
import com.XiaoGangaDEV.module.modules.render.Emoji;
import com.XiaoGangaDEV.module.modules.render.FullBright;
import com.XiaoGangaDEV.module.modules.render.HUD;
import com.XiaoGangaDEV.module.modules.render.Nametags;
import com.XiaoGangaDEV.module.modules.render.NoRender;
import com.XiaoGangaDEV.module.modules.render.Tracers;
import com.XiaoGangaDEV.module.modules.render.Xray;
import com.XiaoGangaDEV.module.modules.world.AntiFall;
import com.XiaoGangaDEV.module.modules.world.AutoArmor;
import com.XiaoGangaDEV.module.modules.world.AutoGG;
import com.XiaoGangaDEV.module.modules.world.AutoL;
import com.XiaoGangaDEV.module.modules.world.Banwave;
import com.XiaoGangaDEV.module.modules.world.Blink;
import com.XiaoGangaDEV.module.modules.world.ChestStealer;
import com.XiaoGangaDEV.module.modules.world.Deathclip;
import com.XiaoGangaDEV.module.modules.world.FastPlace;
import com.XiaoGangaDEV.module.modules.world.NoRotate;
import com.XiaoGangaDEV.module.modules.world.Phase;
import com.XiaoGangaDEV.module.modules.world.PinCracker;
import com.XiaoGangaDEV.module.modules.world.PingSpoof;
import com.XiaoGangaDEV.module.modules.world.SafeWalk;
import com.XiaoGangaDEV.module.modules.world.SpeedMine;
import com.XiaoGangaDEV.module.modules.world.StaffAlerts;
import com.XiaoGangaDEV.utils.render.gl.GLUtils;

import net.minecraft.client.renderer.GlStateManager;

public class ModuleManager
implements Manager {
    public static List<Module> modules = new ArrayList<Module>();
    private boolean enabledNeededMod = true;
    public boolean nicetry = true;

    @Override
    public void init() {
    	modules.add(new NewAntiBot());
    	modules.add(new NewSpeed());
        modules.add(new HUD());
        modules.add(new ClickTp());
        modules.add(new TNTBlock());
        modules.add(new Emoji());
        modules.add(new NewFly());
        modules.add(new AntiAim());
        modules.add(new SpeedMine());
        modules.add(new ClickGui());
        modules.add(new AntiObs());
        modules.add(new AntiFireBall());
        modules.add(new Disabler());
        modules.add(new Sprint());
        modules.add(new KillAura());
        modules.add(new AntiVelocity());
        modules.add(new Criticals());
        modules.add(new Speed());
        modules.add(new Longjump());
        modules.add(new AutoL());
        modules.add(new AutoGG());
        modules.add(new Flight());
        modules.add(new NoFall());
        modules.add(new NoSlowDown());
        modules.add(new CSGOAimBot());
        modules.add(new FastBow());
        modules.add(new AntiBot());
        modules.add(new Freecam());
        modules.add(new MCF());
        modules.add(new Nametags());
        modules.add(new Tracers());
        modules.add(new ESP());
        modules.add(new Regen());
        modules.add(new FastPlace());
        modules.add(new NoRender());
        modules.add(new FullBright());
        modules.add(new AutoHead());
        modules.add(new ChestStealer());
        modules.add(new AutoArmor());
        modules.add(new AntiFall());
        modules.add(new AutoHeal());
        modules.add(new NoRotate());
        modules.add(new Scaffold());
        modules.add(new Sneak());
        modules.add(new SafeWalk());
        modules.add(new Zoot());
        modules.add(new Jesus());
        modules.add(new Phase());
        modules.add(new Chams());
        modules.add(new Deathclip());
        modules.add(new NoStrike());
        modules.add(new SkinFlash());
        modules.add(new AutoAccept());
        modules.add(new Blink());
        modules.add(new Banwave());
        modules.add(new FastUse());
        modules.add(new PingSpoof());
        modules.add(new BowAimBot());
        modules.add(new Xray());
        modules.add(new ChestESP());
        modules.add(new InvCleaner());
        modules.add(new Step());
        modules.add(new Dab());
        modules.add(new Teleport());
        modules.add(new AutoSword());
        modules.add(new Boost());
        modules.add(new Bobbing());
        modules.add(new PinCracker());
        modules.add(new TPAura());
        modules.add(new StaffAlerts());
        
        modules.add(new InvMove());
        modules.add(new Teams());
        this.readSettings();
        for (Module m : modules) {
            m.makeCommand();
        }
        EventBus.getInstance().register(this);
    }

    public static List<Module> getModules() {
        return modules;
    }

    public static Module getModuleByClass(Class<? extends Module> cls) {
        for (Module m : modules) {
            if (m.getClass() != cls) continue;
            return m;
        }
        return null;
    }

    public static Module getModuleByName(String name) {
        for (Module m : modules) {
            if (!m.getName().equalsIgnoreCase(name)) continue;
            return m;
        }
        return null;
    }

    public Module getAlias(String name) {
        for (Module f : modules) {
            if (f.getName().equalsIgnoreCase(name)) {
                return f;
            }
            String[] alias = f.getAlias();
            int length = alias.length;
            int i = 0;
            while (i < length) {
                String s = alias[i];
                if (s.equalsIgnoreCase(name)) {
                    return f;
                }
                ++i;
            }
        }
        return null;
    }

    public static List<Module> getModulesInType(ModuleType t) {
        ArrayList<Module> output = new ArrayList<Module>();
        for (Module m : modules) {
            if (m.getType() != t) continue;
            output.add(m);
        }
        return output;
    }

    @EventHandler
    private void onKeyPress(EventKey e) {
        for (Module m : modules) {
            if (m.getKey() != e.getKey()) continue;
            m.setEnabled(!m.isEnabled());
        }
    }

    @EventHandler
    private void onGLHack(EventRender3D e) {
        GlStateManager.getFloat(2982, (FloatBuffer)GLUtils.MODELVIEW.clear());
        GlStateManager.getFloat(2983, (FloatBuffer)GLUtils.PROJECTION.clear());
        GlStateManager.glGetInteger(2978, (IntBuffer)GLUtils.VIEWPORT.clear());
    }

    @EventHandler
    private void on2DRender(EventRender2D e) {
        if (this.enabledNeededMod) {
            this.enabledNeededMod = false;
            for (Module m : modules) {
                if (!m.enabledOnStartup) continue;
                m.setEnabled(true);
            }
        }
    }

    private void readSettings() {
        List<String> binds = FileManager.read("Binds.txt");
        for (String v : binds) {
            String name = v.split(":")[0];
            String bind = v.split(":")[1];
            Module m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            m.setKey(Keyboard.getKeyIndex((String)bind.toUpperCase()));
        }
        List<String> enabled = FileManager.read("Enabled.txt");
        for (String v : enabled) {
            Module m = ModuleManager.getModuleByName(v);
            if (m == null) continue;
            m.enabledOnStartup = true;
        }
        List<String> vals = FileManager.read("Values.txt");
        for (String v : vals) {
            String name = v.split(":")[0];
            String values = v.split(":")[1];
            Module m = ModuleManager.getModuleByName(name);
            if (m == null) continue;
            for (Value value : m.getValues()) {
                if (!value.getName().equalsIgnoreCase(values)) continue;
                if (value instanceof Option) {
                    value.setValue(Boolean.parseBoolean(v.split(":")[2]));
                    continue;
                }
                if (value instanceof Numbers) {
                    value.setValue(Double.parseDouble(v.split(":")[2]));
                    continue;
                }
                ((Mode)value).setMode(v.split(":")[2]);
            }
        }
    }
}

