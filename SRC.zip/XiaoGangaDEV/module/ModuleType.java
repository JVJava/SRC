/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module;

public enum ModuleType {
    Combat,
    Render,
    Movement,
    Player,
    World;
}

