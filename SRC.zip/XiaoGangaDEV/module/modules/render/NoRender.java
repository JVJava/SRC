/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.render;

import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import java.awt.Color;

public class NoRender
extends Module {
    public NoRender() {
        super("NoRender", new String[]{"noitems"}, ModuleType.Render);
        this.setColor(new Color(166, 185, 123).getRGB());
    }
}

