package com.XiaoGangaDEV.module.modules.render.UI.noti;

public enum NotificationType {
	INFO, WARNING, ERROR, ENABLE, DISABLE;
}
