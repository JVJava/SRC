package com.XiaoGangaDEV.module.modules.render;

import com.XiaoGangaDEV.ClickGUI.newclickgui.NewClickGui;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.Wrapper;

public class ClickGui extends Module {
   public static Option rb = new Option("rainbow", "rainbow", Boolean.valueOf(true));

   public ClickGui() {
      super("ClickGui", new String[]{"clickui"}, ModuleType.Render);
   }

   public void onEnable() {
      Wrapper.mc.displayGuiScreen(new NewClickGui());
      this.setEnabled(false);
   }
}
