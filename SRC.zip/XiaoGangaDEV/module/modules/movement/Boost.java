/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.movement;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.TimerUtil;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.Timer;

public class Boost
extends Module {
    private TimerUtil timer = new TimerUtil();

    public Boost() {
        super("Boost", new String[]{"boost"}, ModuleType.Movement);
        this.setColor(new Color(216, 253, 100).getRGB());
    }

    @EventHandler
    public void onUpdate(EventPreUpdate event) {
        this.mc.timer.timerSpeed = 3.0f;
        if (this.mc.thePlayer.ticksExisted % 15 == 0) {
            this.setEnabled(false);
        }
    }

    @Override
    public void onDisable() {
        this.timer.reset();
        this.mc.timer.timerSpeed = 1.0f;
    }
}

