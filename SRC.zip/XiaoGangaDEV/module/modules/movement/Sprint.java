/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.movement;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.FoodStats;

public class Sprint
extends Module {
    private Option<Boolean> omni = new Option<Boolean>("Omni-Directional", "omni", true);

    public Sprint() {
        super("Sprint", new String[]{"run"}, ModuleType.Movement);
        this.setColor(new Color(158, 205, 125).getRGB());
        this.addValues(this.omni);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        if (this.mc.thePlayer.getFoodStats().getFoodLevel() > 6 && this.omni.getValue() != false ? this.mc.thePlayer.moving() : this.mc.thePlayer.moveForward > 0.0f) {
            this.mc.thePlayer.setSprinting(true);
        }
    }
}

