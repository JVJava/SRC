/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.movement;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;

public class setColor
extends Module {
    public static Numbers<Double> r = new Numbers<Double>("Red", "Red", 255.0, 0.0, 255.0, 1.0);
    public static Numbers<Double> g = new Numbers<Double>("Green", "Green", 255.0, 0.0, 255.0, 1.0);
    public static Numbers<Double> b = new Numbers<Double>("Blue", "Blue", 255.0, 0.0, 255.0, 1.0);
    public static Numbers<Double> a = new Numbers<Double>("Alpha", "Alpha", 255.0, 0.0, 255.0, 1.0);

    public setColor() {
        super("CustomColor", new String[]{"SetColor"}, ModuleType.Render);
        this.addValues(r, g, b, a);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e) {
        this.setEnabled(false);
    }
}

