/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.movement;

import java.awt.Color;
import java.util.Random;
import java.util.TimerTask;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventMove;
import com.XiaoGangaDEV.api.events.world.EventPostUpdate;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.TimerUtil;
import com.XiaoGangaDEV.utils.math.MathUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.boss.EntityDragon;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.MathHelper;
import net.minecraft.util.MovementInput;
import net.minecraft.util.Timer;

public class NewFly
extends Module {
    public Mode mode = new Mode("Mode", "Mode", (Enum[])FlyMode.values(), (Enum)FlyMode.Motion);
    private Option<Boolean> lagcheck = new Option<Boolean>("LagCheck", "LagCheck", true);
    private Option<Boolean> dragonvalue = new Option<Boolean>("Dragon", "Dragon", false);
    private static Numbers<Double> boost = new Numbers<Double>("Boost", "Boost", 0.0, 0.0, 3.0, 0.2);
    private Option<Boolean> par = new Option<Boolean>("Particle", "Particle", false);
    private TimerUtil time = new TimerUtil();
    private TimerUtil kickTimer = new TimerUtil();
    private double movementSpeed;
    private int hypixelCounter;
    private EntityDragon dragon;
    private int hypixelCounter2;
    int counter;
    int level;
    private double flyHeight;
    private boolean dragoncrea = false;
    private int zoom;
    private int packetCounter;
    private TimerUtil deactivationDelay = new TimerUtil();
    double moveSpeed;
    double lastDist;
    boolean b2;
    boolean fly;

    public NewFly() {
        super("NewFly", new String[]{"newfly", "angel"}, ModuleType.Movement);
        this.setColor(new Color(158, 114, 243).getRGB());
        this.addValues(this.mode, boost, this.lagcheck, this.dragonvalue, this.par);
    }

    /*
     * Enabled aggressive block sorting
     */
    public void goToGround() {
        C03PacketPlayer.C04PacketPlayerPosition packet;
        if (this.flyHeight > 300.0) {
            return;
        }
        double minY = Minecraft.thePlayer.posY - this.flyHeight;
        if (minY <= 0.0) {
            return;
        }
        double y = Minecraft.thePlayer.posY;
        while (y > minY) {
            if ((y -= 8.0) < minY) {
                y = minY;
            }
            packet = new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, y, Minecraft.thePlayer.posZ, true);
            Minecraft.thePlayer.sendQueue.addToSendQueue(packet);
        }
        y = minY;
        while (y < Minecraft.thePlayer.posY) {
            y += 8.0;
            if (y > Minecraft.thePlayer.posY) {
                y = Minecraft.thePlayer.posY;
            }
            packet = new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, y, Minecraft.thePlayer.posZ, true);
            Minecraft.thePlayer.sendQueue.addToSendQueue(packet);
        }
    }

    public void damagePlayer(double d) {
        if (d < 1.0) {
            d = 1.0;
        }
        if (d > (double)MathHelper.floor_double(Minecraft.thePlayer.getMaxHealth())) {
            d = MathHelper.floor_double(Minecraft.thePlayer.getMaxHealth());
        }
        double offset = 0.0625;
        if (Minecraft.thePlayer != null && mc.getNetHandler() != null) {
            if (Minecraft.thePlayer.onGround) {
                int i = 0;
                while ((double)i <= (3.0 + d) / offset) {
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + offset, Minecraft.thePlayer.posZ, false));
                    mc.getNetHandler().addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ, (double)i == (3.0 + d) / offset));
                    ++i;
                }
            }
        }
    }

    @Override
    public void onEnable() {
        this.zoom = 50;
        float forward = MovementInput.moveForward;
        float strafe = MovementInput.moveStrafe;
        if (this.mode.getValue() == FlyMode.Hypixel) {
            this.hypixelCounter = 0;
            this.hypixelCounter2 = 1000;
        }
        if (this.mode.getValue() == FlyMode.HypixelZoom) {
            this.damagePlayer(1.0);
            this.fly = true;
            new java.util.Timer().schedule(new TimerTask(){

                @Override
                public void run() {
                    NewFly.this.fly = false;
                    Minecraft.thePlayer.motionY = 0.42;
                    EventMove.setY(0.42);
                    this.cancel();
                }
            }, 240L);
            this.hypixelCounter = 0;
            this.hypixelCounter2 = 450;
        }
        this.level = 1;
        this.dragoncrea = false;
        this.moveSpeed = 0.1;
        this.b2 = true;
        this.lastDist = 0.0;
    }

    @Override
    public void onDisable() {
        this.hypixelCounter = 0;
        if (((Boolean)this.dragonvalue.getValue()).booleanValue()) {
            Minecraft.theWorld.removeEntity(this.dragon);
        }
        double posX = Minecraft.thePlayer.posX;
        double posY = Minecraft.thePlayer.posY;
        double posZ = Minecraft.thePlayer.posZ;
        this.hypixelCounter2 = 100;
        Timer.timerSpeed = 1.0;
        this.level = 1;
        this.moveSpeed = 0.1;
        this.b2 = false;
        this.lastDist = 0.0;
    }

    /*
     * Enabled aggressive block sorting
     */
    public void updateFlyHeight() {
        double h = 1.0;
        AxisAlignedBB box = Minecraft.thePlayer.getEntityBoundingBox().expand(0.0625, 0.0625, 0.0625);
        this.flyHeight = 0.0;
        while (this.flyHeight < Minecraft.thePlayer.posY) {
            AxisAlignedBB nextBox = box.offset(0.0, -this.flyHeight, 0.0);
            if (Minecraft.theWorld.checkBlockCollision(nextBox)) {
                if (h < 0.0625) {
                    return;
                }
                this.flyHeight -= h;
                h /= 2.0;
            }
            this.flyHeight += h;
        }
    }

    public static boolean isOnGround(double height) {
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    @EventHandler
    private void onUpdate(final EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
        double speed = Math.max(8.0, this.getBaseMoveSpeed());
        if (this.mode.getValue() == FlyMode.Motion) {
            Minecraft.thePlayer.onGround = false;
            e.setOnground(NewFly.isOnGround(0.001));
            if (Minecraft.thePlayer.moving()) {
                if (Minecraft.thePlayer.hurtTime > 15) {
                    e.setCancelled(false);
                } else {
                    new java.util.Timer().schedule(new TimerTask(){

                        @Override
                        public void run() {
                            e.setCancelled(true);
                            this.cancel();
                        }
                    }, 10L);
                }
            } else {
                e.setCancelled(false);
                Minecraft.thePlayer.motionX = 0.0;
                Minecraft.thePlayer.motionY = 0.0;
                Minecraft.thePlayer.motionZ = 0.0;
            }
            Minecraft.thePlayer.motionY = Minecraft.thePlayer.movementInput.jump ? speed * 0.6 : (Minecraft.thePlayer.movementInput.sneak ? -speed * 0.6 : 0.0);
            this.updateFlyHeight();
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
        } else if (this.mode.getValue() == FlyMode.Vanilla) {
            Minecraft.thePlayer.motionY = Minecraft.thePlayer.movementInput.jump ? 1.0 : (Minecraft.thePlayer.movementInput.sneak ? -1.0 : 0.0);
            if (Minecraft.thePlayer.moving()) {
                Minecraft.thePlayer.setSpeed(3.0);
            } else {
                Minecraft.thePlayer.setSpeed(0.0);
            }
            Minecraft.thePlayer.capabilities.allowFlying = true;
        } else if (this.mode.getValue() == FlyMode.Hypixel || this.mode.getValue() == FlyMode.HypixelZoom) {
            Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ);
            switch (this.counter) {
                case 1: {
                    break;
                }
                case 2: {
                    Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 1.0E-5, Minecraft.thePlayer.posZ);
                    this.counter = 0;
                }
            }
            ++this.counter;
            Minecraft.thePlayer.motionY = 0.0;
        }
    }

    @EventHandler
    public void onEvent(EventPostUpdate e) {
        double posZ2;
        double motionY;
        float cos;
        double posX;
        double posX4;
        float f;
        double motionZ;
        float n2;
        double posY;
        double motionX;
        double posZ;
        if (this.mode.getValue() == FlyMode.HypixelZoom && this.fly) {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
            Minecraft.thePlayer.jumpMovementFactor = 0.0f;
            Minecraft.thePlayer.onGround = false;
        }
        if (((Boolean)this.dragonvalue.getValue()).booleanValue() && !this.dragoncrea) {
            this.dragoncrea = true;
            this.dragon = new EntityDragon(Minecraft.theWorld);
            Minecraft.theWorld.addEntityToWorld(666, this.dragon);
            Minecraft.thePlayer.ridingEntity = this.dragon;
        } else if (((Boolean)this.dragonvalue.getValue()).booleanValue()) {
            posX4 = Minecraft.thePlayer.posX;
            posX = posX4 - (double)(MathHelper.cos(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f);
            posY = Minecraft.thePlayer.posY;
            posZ2 = Minecraft.thePlayer.posZ;
            posZ = posZ2 - (double)(MathHelper.sin(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f);
            f = 0.4f;
            n2 = -MathHelper.sin(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f);
            motionX = n2 * MathHelper.cos(Minecraft.thePlayer.rotationPitch / 180.0f * 3.1415927f) * 0.4f;
            cos = MathHelper.cos(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f);
            motionZ = cos * MathHelper.cos(Minecraft.thePlayer.rotationPitch / 180.0f * 3.1415927f) * 0.4f;
            motionY = -MathHelper.sin((Minecraft.thePlayer.rotationPitch + 2.0f) / 180.0f * 3.1415927f) * 0.4f;
            double xCoord = posX + motionX;
            double yCoord = posY + motionY;
            double zCoord = posZ + motionZ;
            this.dragon.rotationPitch = Minecraft.thePlayer.rotationPitch;
            this.dragon.rotationYaw = Minecraft.thePlayer.rotationYawHead - 180.0f;
            this.dragon.setRotationYawHead(Minecraft.thePlayer.rotationYawHead);
            this.dragon.setPosition(xCoord, Minecraft.thePlayer.posY - 2.0, zCoord);
        }
        if (((Boolean)this.par.getValue()).booleanValue()) {
            posX4 = Minecraft.thePlayer.posX;
            posX = posX4 - (double)(MathHelper.cos(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f);
            posY = Minecraft.thePlayer.posY;
            posZ2 = Minecraft.thePlayer.posZ;
            posZ = posZ2 - (double)(MathHelper.sin(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f) * 0.16f);
            f = 0.4f;
            n2 = -MathHelper.sin(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f);
            motionX = n2 * MathHelper.cos(Minecraft.thePlayer.rotationPitch / 180.0f * 3.1415927f) * 0.4f;
            cos = MathHelper.cos(Minecraft.thePlayer.rotationYaw / 180.0f * 3.1415927f);
            motionZ = cos * MathHelper.cos(Minecraft.thePlayer.rotationPitch / 180.0f * 3.1415927f) * 0.4f;
            motionY = -MathHelper.sin((Minecraft.thePlayer.rotationPitch + 2.0f) / 180.0f * 3.1415927f) * 0.4f;
            for (int i = 0; i < 90; ++i) {
                WorldClient theWorld = Minecraft.theWorld;
                EnumParticleTypes particleType = i % 4 == 0 ? EnumParticleTypes.CRIT_MAGIC : (new Random().nextBoolean() ? EnumParticleTypes.HEART : EnumParticleTypes.ENCHANTMENT_TABLE);
                double xCoord = posX + motionX;
                double yCoord = posY + motionY;
                double zCoord = posZ + motionZ;
                double motionX2 = Minecraft.thePlayer.motionX;
                double motionY2 = Minecraft.thePlayer.motionY;
                theWorld.spawnParticle(particleType, xCoord, yCoord, zCoord, motionX2, motionY2, Minecraft.thePlayer.motionZ, new int[0]);
            }
        }
    }

    @EventHandler
    public void onPost(EventPostUpdate e) {
        if (this.mode.getValue() == FlyMode.Hypixel || this.mode.getValue() == FlyMode.HypixelZoom) {
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            double xDist = Minecraft.thePlayer.posX - Minecraft.thePlayer.prevPosX;
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            double zDist = Minecraft.thePlayer.posZ - Minecraft.thePlayer.prevPosZ;
            this.lastDist = Math.sqrt(xDist * xDist + zDist * zDist);
        }
    }

    @EventHandler
    private void onMove(EventMove e) {
        block34: {
            block33: {
                float strafe;
                float yaw;
                float forward;
                block38: {
                    int n;
                    block36: {
                        block41: {
                            block40: {
                                block39: {
                                    block37: {
                                        block35: {
                                            if (this.mode.getValue() != FlyMode.Hypixel && this.mode.getValue() != FlyMode.HypixelZoom) break block33;
                                            if (this.fly) break block34;
                                            if (this.zoom > 0 && ((Double)boost.getValue()).floatValue() > 0.0f) {
                                                Timer.timerSpeed = 1.0f + ((Double)boost.getValue()).floatValue();
                                                if (this.zoom < 5) {
                                                    float percent = this.zoom / 10;
                                                    if ((double)percent > 1.0) {
                                                        percent = 1.0f;
                                                    }
                                                    Timer.timerSpeed = 1.0f + ((Double)boost.getValue()).floatValue() * percent;
                                                }
                                            } else {
                                                Timer.timerSpeed = 1.0;
                                            }
                                            --this.zoom;
                                            forward = MovementInput.moveForward;
                                            strafe = MovementInput.moveStrafe;
                                            yaw = Minecraft.thePlayer.rotationYaw;
                                            double mx = Math.cos(Math.toRadians(yaw + 90.0f));
                                            double mz = Math.sin(Math.toRadians(yaw + 90.0f));
                                            if (forward == 0.0f && strafe == 0.0f) {
                                                EventMove.x = 0.0;
                                                EventMove.z = 0.0;
                                            } else if (forward != 0.0f) {
                                                if (strafe >= 1.0f) {
                                                    yaw += (float)(forward > 0.0f ? -45 : 45);
                                                    strafe = 0.0f;
                                                } else if (strafe <= -1.0f) {
                                                    yaw += (float)(forward > 0.0f ? 45 : -45);
                                                    strafe = 0.0f;
                                                }
                                                if (forward > 0.0f) {
                                                    forward = 1.0f;
                                                } else if (forward < 0.0f) {
                                                    forward = -1.0f;
                                                }
                                            }
                                            if (!this.b2) break block34;
                                            if (this.level != 1) break block35;
                                            Minecraft.getMinecraft();
                                            if (Minecraft.thePlayer.moveForward != 0.0f) break block36;
                                            Minecraft.getMinecraft();
                                            if (Minecraft.thePlayer.moveStrafing != 0.0f) break block36;
                                        }
                                        if (this.level != 2) break block37;
                                        this.level = 3;
                                        this.moveSpeed *= 2.7899999;
                                        break block38;
                                    }
                                    if (this.level != 3) break block39;
                                    this.level = 4;
                                    double difference = (Minecraft.thePlayer.ticksExisted % 2 == 0 ? 0.0103 : 0.0123) * (this.lastDist - MathUtil.getBaseMovementSpeed());
                                    this.moveSpeed = this.lastDist - difference;
                                    break block38;
                                }
                                Minecraft.getMinecraft();
                                Minecraft.getMinecraft();
                                Minecraft.getMinecraft();
                                Minecraft.getMinecraft();
                                if (Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.boundingBox.offset(0.0, Minecraft.thePlayer.motionY, 0.0)).size() > 0) break block40;
                                Minecraft.getMinecraft();
                                if (!Minecraft.thePlayer.isCollidedVertically) break block41;
                            }
                            this.level = 1;
                        }
                        this.moveSpeed = this.lastDist - this.lastDist / 159.0;
                        break block38;
                    }
                    this.level = 2;
                    Minecraft.getMinecraft();
                    if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
                        Minecraft.getMinecraft();
                        n = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier() + 1;
                    } else {
                        n = 0;
                    }
                    int amplifier = n;
                    Minecraft.getMinecraft();
                    double boost = Minecraft.thePlayer.isPotionActive(Potion.moveSpeed) ? 1.56 : 2.034;
                    this.moveSpeed = boost * MathUtil.getBaseMovementSpeed();
                }
                this.moveSpeed = this.mode.getValue() == FlyMode.HypixelZoom ? Math.max(this.moveSpeed, MathUtil.getBaseMovementSpeed()) : MathUtil.getBaseMovementSpeed();
                EventMove.x = (double)forward * this.moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f)) + (double)strafe * this.moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f));
                EventMove.z = (double)forward * this.moveSpeed * Math.sin(Math.toRadians(yaw + 90.0f)) - (double)strafe * this.moveSpeed * Math.cos(Math.toRadians(yaw + 90.0f));
                if (forward == 0.0f && strafe == 0.0f) {
                    EventMove.x = 0.0;
                    EventMove.z = 0.0;
                }
                break block34;
            }
            if (this.mode.getValue() == FlyMode.Motion) {
                float forward = MovementInput.moveForward;
                float strafe = MovementInput.moveStrafe;
                float yaw = Minecraft.thePlayer.rotationYaw;
                if (forward == 0.0f && strafe == 0.0f) {
                    EventMove.x = 0.0;
                    EventMove.z = 0.0;
                } else if (forward != 0.0f) {
                    if (strafe >= 1.0f) {
                        yaw += (float)(forward > 0.0f ? -45 : 45);
                        strafe = 0.0f;
                    } else if (strafe <= -1.0f) {
                        yaw += (float)(forward > 0.0f ? 45 : -45);
                        strafe = 0.0f;
                    }
                    if (forward > 0.0f) {
                        forward = 1.0f;
                    } else if (forward < 0.0f) {
                        forward = -1.0f;
                    }
                }
                Minecraft.thePlayer.onGround = false;
                if (Minecraft.thePlayer.isMoving()) {
                    Minecraft.thePlayer.motionY = -0.5;
                    this.moveSpeed = 7.59;
                } else {
                    this.moveSpeed = 0.0;
                }
                this.moveSpeed = Math.max(this.moveSpeed, MathUtil.getBaseMovementSpeed());
                Minecraft.thePlayer.setMoveSpeed(e, this.moveSpeed);
            }
        }
    }

    double getBaseMoveSpeed() {
        double baseSpeed = 0.275;
        if (Minecraft.thePlayer.isPotionActive(Potion.moveSpeed)) {
            int amplifier = Minecraft.thePlayer.getActivePotionEffect(Potion.moveSpeed).getAmplifier();
            baseSpeed *= 1.0 + 0.2 * (double)(amplifier + 1);
        }
        return baseSpeed;
    }

    public static enum FlyMode {
        Vanilla,
        Hypixel,
        Motion,
        HypixelZoom;

    }

}

