/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.movement;

import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

class BlockCache {
    static BlockPos position;
    static EnumFacing facing;
    final Scaffold this$0;

    private BlockCache(Scaffold var1, BlockPos position, EnumFacing facing) {
        this.this$0 = var1;
        BlockCache.position = position;
        BlockCache.facing = facing;
    }

    private BlockPos getPosition() {
        return position;
    }

    private EnumFacing getFacing() {
        return facing;
    }

    static BlockPos access$0(BlockCache var0) {
        return var0.getPosition();
    }

    static EnumFacing access$1(BlockCache var0) {
        return var0.getFacing();
    }

    static BlockPos access$2(BlockCache var0) {
        return position;
    }

    static EnumFacing access$3(BlockCache var0) {
        return facing;
    }

    BlockCache(Scaffold var1, BlockPos var2, EnumFacing var3, BlockCache var4) {
        this(var1, var2, var3);
    }
}

