/*
 * Decompiled with CFR 0.148.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package com.XiaoGangaDEV.module.modules.movement;

import java.awt.Color;
import java.awt.event.ActionListener;
import java.util.Arrays;
import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.Timer;

import com.XiaoGangaDEV.Client;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.rendering.EventRender2D;
import com.XiaoGangaDEV.api.events.rendering.EventRender3D;
import com.XiaoGangaDEV.api.events.world.EventPostUpdate;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.management.ModuleManager;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.module.modules.render.ESP.ESPMode;
import com.XiaoGangaDEV.utils.math.RotationUtil;
import com.XiaoGangaDEV.utils.render.RenderUtil;

import io.netty.util.TimerTask;
import javafx.event.ActionEvent;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockCarpet;
import net.minecraft.block.BlockContainer;
import net.minecraft.block.BlockLadder;
import net.minecraft.block.BlockSkull;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.init.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.Vec3;

public class Scaffold
extends Module {
    public static Option tower = new Option<Boolean>("Tower", "tower", true);
    public static Option towermove = new Option<Boolean>("Towermove", "Towermove", true);
    public static Option silent = new Option<Boolean>("Silent", "Silent", true);
    private Option<Boolean> swing = new Option<Boolean>("Swing", "Swing", false);
    public static Option bob = new Option<Boolean>("Bobbing", "Bobbing", false);
    public static Option aac = new Option<Boolean>("AAC", "AAC", false);
    private Option<Boolean> Down = new Option<Boolean>("Down", "Down", true);
    public static Mode<Enum> espmode = new Mode("BoxMode", "BoxMode", (Enum[])ESPMode.values(), (Enum)ESPMode.Outline);
    private List invalid;
    private List<Block> blacklist = Arrays.asList(Blocks.air, Blocks.water, Blocks.torch, Blocks.redstone_torch, Blocks.ladder, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.enchanting_table, Blocks.carpet, Blocks.glass_pane, Blocks.stained_glass_pane, Blocks.iron_bars, Blocks.chest, Blocks.torch, Blocks.anvil, Blocks.web, Blocks.redstone_torch, Blocks.brewing_stand, Blocks.waterlily, Blocks.farmland, Blocks.sand, Blocks.beacon);
    public static BlockCache blockCache;
    public static boolean Start;
    private int currentItem;
    private int width = 0;

    public Scaffold() {
        super("Scaffold", new String[]{"magiccarpet", "blockplacer", "airwalk"}, ModuleType.Movement);
        this.invalid = Arrays.asList(Blocks.air, Blocks.water, Blocks.fire, Blocks.flowing_water, Blocks.lava, Blocks.flowing_lava, Blocks.chest, Blocks.enchanting_table, Blocks.tnt);
        this.addValues(tower, towermove, silent, this.swing, bob, aac, espmode);
        this.currentItem = 0;
        this.addValues(this.Down);
    }

    @Override
    public void onEnable() {
        this.currentItem = Minecraft.thePlayer.inventory.currentItem;
    }

    @Override
    public void onDisable() {
        Minecraft.thePlayer.inventory.currentItem = this.currentItem;
    }

    @EventHandler
    private void render(EventRender2D e) {
        ScaledResolution res = new ScaledResolution(mc);
        int color = Colors.getColor(255, 0, 0);
        if (this.getBlockCount() > 64 && 256 > this.getBlockCount()) {
            color = Colors.getColor(255, 255, 0);
        } else if (this.getBlockCount() > 256) {
            color = Colors.getColor(0, 255, 0);
        }
        if (this.getBlockCount() >= 100 && this.getBlockCount() < 1000) {
            this.width = 7;
        }
        if (this.getBlockCount() >= 10 && this.getBlockCount() < 100) {
            this.width = 5;
        }
        if (this.getBlockCount() >= 0 && this.getBlockCount() < 10) {
            this.width = 3;
        }
    }

    @EventHandler
    private void render(EventRender3D e) {
        double z2;
        block9: {
            block11: {
                double x;
                double y;
                Color color2;
                double z;
                block10: {
                    espmode.getValue();
                    if (espmode.getValue() != ESPMode.Outline) break block9;
                    Color color = new Color(Colors.BLACK.c);
                    color2 = new Color(Colors.ORANGE.c);
                    x = Minecraft.thePlayer.lastTickPosX + (Minecraft.thePlayer.posX - Minecraft.thePlayer.lastTickPosX) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosX;
                    y = Minecraft.thePlayer.lastTickPosY + (Minecraft.thePlayer.posY - Minecraft.thePlayer.lastTickPosY) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosY;
                    z = Minecraft.thePlayer.lastTickPosZ + (Minecraft.thePlayer.posZ - Minecraft.thePlayer.lastTickPosZ) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
                    double x2 = Minecraft.thePlayer.lastTickPosX + (Minecraft.thePlayer.posX - Minecraft.thePlayer.lastTickPosX) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosX;
                    double y2 = Minecraft.thePlayer.lastTickPosY + (Minecraft.thePlayer.posY - Minecraft.thePlayer.lastTickPosY) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosY;
                    z2 = Minecraft.thePlayer.lastTickPosZ + (Minecraft.thePlayer.posZ - Minecraft.thePlayer.lastTickPosZ) * (double)Scaffold.mc.timer.renderPartialTicks - RenderManager.renderPosZ;
                    double d = Minecraft.thePlayer.isSneaking() ? 0.25 : 0.0;
                    GL11.glPushMatrix();
                    GL11.glEnable((int)3042);
                    GL11.glBlendFunc((int)770, (int)771);
                    double rotAdd = -0.25 * (double)(Math.abs(Minecraft.thePlayer.rotationPitch) / 90.0f);
                    GL11.glDisable((int)3553);
                    GL11.glEnable((int)2848);
                    GL11.glDisable((int)2929);
                    GL11.glDepthMask((boolean)false);
                    GL11.glColor4f((float)((float)color.getRed() / 255.0f), (float)((float)color.getGreen() / 255.0f), (float)((float)color.getBlue() / 255.0f), (float)1.0f);
                    GL11.glLineWidth((float)2.0f);
                    RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x -= 0.65, (y += (double)Minecraft.thePlayer.getEyeHeight() + 0.35 - d) - 2.0, z -= 0.65, x + 1.3, y - 2.0, z + 1.3));
                    RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x2 -= 0.5, y - 2.0, z2 -= 0.5, x2 + 1.0, y - 2.0, z2 + 1.0));
                    if (Scaffold.mc.gameSettings.keyBindJump.pressed) break block10;
                    Client.getModuleManager();
                    if (!ModuleManager.getModuleByName("Speed").isEnabled()) break block11;
                    Minecraft.getMinecraft();
                    if (Minecraft.thePlayer.moveForward == 0.0f) break block11;
                }
                GL11.glColor4f((float)((float)color2.getRed() / 255.0f), (float)((float)color2.getGreen() / 255.0f), (float)((float)color2.getBlue() / 255.0f), (float)1.0f);
                RenderUtil.drawOutlinedBoundingBox(new AxisAlignedBB(x, y - 2.0, z, x + 1.3, y - 2.0, z + 1.3));
            }
            GL11.glDisable((int)2848);
            GL11.glEnable((int)3553);
            GL11.glEnable((int)2929);
            GL11.glDepthMask((boolean)true);
            GL11.glDisable((int)3042);
            GL11.glPopMatrix();
        }
        if (espmode.getValue() == ESPMode.Outline) {
            Scaffold.mc.entityRenderer.setupCameraTransform(Scaffold.mc.timer.renderPartialTicks, 10);
            BlockPos place = BlockCache.position;
            EnumFacing face = BlockCache.facing;
            double x1 = (double)place.getX() - RenderManager.renderPosX;
            double x2 = (double)place.getX() - RenderManager.renderPosX + 1.0;
            double y1 = (double)place.getY() - RenderManager.renderPosY;
            double y2 = (double)place.getY() - RenderManager.renderPosY + 1.0;
            double z1 = (double)place.getZ() - RenderManager.renderPosZ;
            z2 = (double)place.getZ() - RenderManager.renderPosZ + 1.0;
            y1 += (double)face.getFrontOffsetY();
            if (face.getFrontOffsetX() < 0) {
                x2 += (double)face.getFrontOffsetX();
            } else {
                x1 += (double)face.getFrontOffsetX();
            }
            if (face.getFrontOffsetZ() < 0) {
                z2 += (double)face.getFrontOffsetZ();
            } else {
                z1 += (double)face.getFrontOffsetZ();
            }
            if (place != null || face != null || place != null && face != null) {
                GL11.glPushMatrix();
                GL11.glEnable((int)3042);
                GL11.glBlendFunc((int)770, (int)771);
                GL11.glShadeModel((int)7425);
                GL11.glDisable((int)3553);
                GL11.glEnable((int)2848);
                GL11.glDisable((int)2929);
                GL11.glDisable((int)2896);
                GL11.glDepthMask((boolean)false);
                GL11.glHint((int)3154, (int)4354);
                GL11.glColor4f((float)(((Double)setColor.r.getValue()).floatValue() / 255.0f), (float)(((Double)setColor.g.getValue()).floatValue() / 255.0f), (float)(((Double)setColor.b.getValue()).floatValue() / 255.0f), (float)(((Double)setColor.a.getValue()).floatValue() / 255.0f));
                RenderUtil.drawBoundingBox(new AxisAlignedBB(x1, y1, z1, x2, y2, z2));
                GL11.glDepthMask((boolean)true);
                GL11.glEnable((int)2929);
                GL11.glDisable((int)2848);
                GL11.glEnable((int)3553);
                GL11.glDisable((int)3042);
                GL11.glPopMatrix();
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
            }
        }

        }

        		
        	
        
    
    


    @EventHandler
    private void onUpdate(EventPreUpdate event) {
        if (!((Boolean)bob.getValue()).booleanValue()) {
            Minecraft.thePlayer.cameraYaw = 0.0f;
        }
        this.setSuffix("Hypixel");
        if (((Boolean)aac.getValue()).booleanValue()) {
            Minecraft.thePlayer.setSprinting(false);
        }
        if (this.grabBlockSlot() != -1 && (blockCache = this.grab()) != null) {
            float[] rotations = RotationUtil.grabBlockRotations(BlockCache.access$0(blockCache));
            event.setYaw(rotations[0]);
            event.setPitch(RotationUtil.getVecRotation(this.grabPosition(BlockCache.access$0(blockCache), BlockCache.access$1(blockCache)))[1] - 3.0f);
            float[] rot = this.getRotations(BlockCache.position, BlockCache.facing);
            Minecraft.thePlayer.renderYawOffset = rotations[0] + 180.0f;
            Minecraft.thePlayer.rotationYawHead = rotations[0] + 180.0f;
        }
        BlockPos underPos = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ);
        Block underBlock = Minecraft.theWorld.getBlockState(underPos).getBlock();
        BlockData data = this.getBlockData(underPos);
        if (!Scaffold.mc.gameSettings.keyBindJump.isKeyDown()) {
            if (PlayerUtil.isMoving2() && ((Boolean)towermove.getValue()).booleanValue() && ((Boolean)tower.getValue()).booleanValue()) {
                if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75)) {
                    if (Minecraft.thePlayer.motionY > 0.23) {
                        if (Minecraft.thePlayer.motionY < 0.25) {
                            Minecraft.thePlayer.motionY = (double)Math.round(Minecraft.thePlayer.posY) - Minecraft.thePlayer.posY;
                        }
                    }
                }
                if (!MoveUtils.isOnGround(1.0E-4)) {
                    if (Minecraft.thePlayer.motionY > 0.1) {
                        if (Minecraft.thePlayer.posY >= (double)Math.round(Minecraft.thePlayer.posY) - 1.0E-4) {
                            if (Minecraft.thePlayer.posY <= (double)Math.round(Minecraft.thePlayer.posY) + 1.0E-4) {
                                Minecraft.thePlayer.motionY = 0.0;
                            }
                        }
                    }
                }
            }
            return;
        }
        if (Minecraft.thePlayer.moving() && ((Boolean)towermove.getValue()).booleanValue() && ((Boolean)tower.getValue()).booleanValue()) {
            if (MoveUtils.isOnGround(0.76) && !MoveUtils.isOnGround(0.75)) {
                if (Minecraft.thePlayer.motionY > 0.23) {
                    if (Minecraft.thePlayer.motionY < 0.25) {
                        Minecraft.thePlayer.motionY = (double)Math.round(Minecraft.thePlayer.posY) - Minecraft.thePlayer.posY;
                    }
                }
            }
            if (MoveUtils.isOnGround(1.0E-4)) {
                Minecraft.thePlayer.motionY = 0.42;
                Minecraft.thePlayer.motionX *= 0.9;
                Minecraft.thePlayer.motionZ *= 0.9;
            } else if (Minecraft.thePlayer.posY >= (double)Math.round(Minecraft.thePlayer.posY) - 1.0E-4) {
                if (Minecraft.thePlayer.posY <= (double)Math.round(Minecraft.thePlayer.posY) + 1.0E-4) {
                    Minecraft.thePlayer.motionY = 0.0;
                }
            }
        } else {
            Minecraft.thePlayer.motionX = 0.0;
            Minecraft.thePlayer.motionZ = 0.0;
            Minecraft.thePlayer.jumpMovementFactor = 0.0f;
            if (this.isAirBlock(underBlock) && data != null) {
                Minecraft.thePlayer.motionY = 0.4196;
                Minecraft.thePlayer.motionX *= 0.75;
                Minecraft.thePlayer.motionZ *= 0.75;
            }
        }
    }

    private BlockData getBlockData(BlockPos pos) {
        if (this.isPosSolid(pos.add(0, 1, 0))) {
            if (Minecraft.thePlayer.isSneaking()) {
                return new BlockData(pos.add(0, 1, 0), EnumFacing.DOWN);
            }
        }
        if (this.isPosSolid(pos.add(0, -1, 0))) {
            return new BlockData(pos.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos.add(-1, 0, 0))) {
            return new BlockData(pos.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos.add(1, 0, 0))) {
            return new BlockData(pos.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos.add(0, 0, 1))) {
            return new BlockData(pos.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos.add(0, 0, -1))) {
            return new BlockData(pos.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos1 = pos.add(-1, 0, 0);
        if (this.isPosSolid(pos1.add(0, -1, 0))) {
            return new BlockData(pos1.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos1.add(-1, 0, 0))) {
            return new BlockData(pos1.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos1.add(1, 0, 0))) {
            return new BlockData(pos1.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos1.add(0, 0, 1))) {
            return new BlockData(pos1.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos1.add(0, 0, -1))) {
            return new BlockData(pos1.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos2 = pos.add(1, 0, 0);
        if (this.isPosSolid(pos2.add(0, -1, 0))) {
            return new BlockData(pos2.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos2.add(-1, 0, 0))) {
            return new BlockData(pos2.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos2.add(1, 0, 0))) {
            return new BlockData(pos2.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos2.add(0, 0, 1))) {
            return new BlockData(pos2.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos2.add(0, 0, -1))) {
            return new BlockData(pos2.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos3 = pos.add(0, 0, 1);
        if (this.isPosSolid(pos3.add(0, -1, 0))) {
            return new BlockData(pos3.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos3.add(-1, 0, 0))) {
            return new BlockData(pos3.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos3.add(1, 0, 0))) {
            return new BlockData(pos3.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos3.add(0, 0, 1))) {
            return new BlockData(pos3.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos3.add(0, 0, -1))) {
            return new BlockData(pos3.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos4 = pos.add(0, 0, -1);
        if (this.isPosSolid(pos4.add(0, -1, 0))) {
            return new BlockData(pos4.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos4.add(-1, 0, 0))) {
            return new BlockData(pos4.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos4.add(1, 0, 0))) {
            return new BlockData(pos4.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos4.add(0, 0, 1))) {
            return new BlockData(pos4.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos4.add(0, 0, -1))) {
            return new BlockData(pos4.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos19 = pos.add(-2, 0, 0);
        if (this.isPosSolid(pos1.add(0, -1, 0))) {
            return new BlockData(pos1.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos1.add(-1, 0, 0))) {
            return new BlockData(pos1.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos1.add(1, 0, 0))) {
            return new BlockData(pos1.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos1.add(0, 0, 1))) {
            return new BlockData(pos1.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos1.add(0, 0, -1))) {
            return new BlockData(pos1.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos29 = pos.add(2, 0, 0);
        if (this.isPosSolid(pos2.add(0, -1, 0))) {
            return new BlockData(pos2.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos2.add(-1, 0, 0))) {
            return new BlockData(pos2.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos2.add(1, 0, 0))) {
            return new BlockData(pos2.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos2.add(0, 0, 1))) {
            return new BlockData(pos2.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos2.add(0, 0, -1))) {
            return new BlockData(pos2.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos39 = pos.add(0, 0, 2);
        if (this.isPosSolid(pos3.add(0, -1, 0))) {
            return new BlockData(pos3.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos3.add(-1, 0, 0))) {
            return new BlockData(pos3.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos3.add(1, 0, 0))) {
            return new BlockData(pos3.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos3.add(0, 0, 1))) {
            return new BlockData(pos3.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos3.add(0, 0, -1))) {
            return new BlockData(pos3.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos49 = pos.add(0, 0, -2);
        if (this.isPosSolid(pos4.add(0, -1, 0))) {
            return new BlockData(pos4.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos4.add(-1, 0, 0))) {
            return new BlockData(pos4.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos4.add(1, 0, 0))) {
            return new BlockData(pos4.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos4.add(0, 0, 1))) {
            return new BlockData(pos4.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos4.add(0, 0, -1))) {
            return new BlockData(pos4.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos5 = pos.add(0, -1, 0);
        if (this.isPosSolid(pos5.add(0, -1, 0))) {
            return new BlockData(pos5.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos5.add(-1, 0, 0))) {
            return new BlockData(pos5.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos5.add(1, 0, 0))) {
            return new BlockData(pos5.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos5.add(0, 0, 1))) {
            return new BlockData(pos5.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos5.add(0, 0, -1))) {
            return new BlockData(pos5.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos6 = pos5.add(1, 0, 0);
        if (this.isPosSolid(pos6.add(0, -1, 0))) {
            return new BlockData(pos6.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos6.add(-1, 0, 0))) {
            return new BlockData(pos6.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos6.add(1, 0, 0))) {
            return new BlockData(pos6.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos6.add(0, 0, 1))) {
            return new BlockData(pos6.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos6.add(0, 0, -1))) {
            return new BlockData(pos6.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos7 = pos5.add(-1, 0, 0);
        if (this.isPosSolid(pos7.add(0, -1, 0))) {
            return new BlockData(pos7.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos7.add(-1, 0, 0))) {
            return new BlockData(pos7.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos7.add(1, 0, 0))) {
            return new BlockData(pos7.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos7.add(0, 0, 1))) {
            return new BlockData(pos7.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos7.add(0, 0, -1))) {
            return new BlockData(pos7.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos8 = pos5.add(0, 0, 1);
        if (this.isPosSolid(pos8.add(0, -1, 0))) {
            return new BlockData(pos8.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos8.add(-1, 0, 0))) {
            return new BlockData(pos8.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos8.add(1, 0, 0))) {
            return new BlockData(pos8.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos8.add(0, 0, 1))) {
            return new BlockData(pos8.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos8.add(0, 0, -1))) {
            return new BlockData(pos8.add(0, 0, -1), EnumFacing.SOUTH);
        }
        BlockPos pos9 = pos5.add(0, 0, -1);
        if (this.isPosSolid(pos9.add(0, -1, 0))) {
            return new BlockData(pos9.add(0, -1, 0), EnumFacing.UP);
        }
        if (this.isPosSolid(pos9.add(-1, 0, 0))) {
            return new BlockData(pos9.add(-1, 0, 0), EnumFacing.EAST);
        }
        if (this.isPosSolid(pos9.add(1, 0, 0))) {
            return new BlockData(pos9.add(1, 0, 0), EnumFacing.WEST);
        }
        if (this.isPosSolid(pos9.add(0, 0, 1))) {
            return new BlockData(pos9.add(0, 0, 1), EnumFacing.NORTH);
        }
        if (this.isPosSolid(pos9.add(0, 0, -1))) {
            return new BlockData(pos9.add(0, 0, -1), EnumFacing.SOUTH);
        }
        return null;
    }

    private boolean isPosSolid(BlockPos pos) {
        Block block = Minecraft.theWorld.getBlockState(pos).getBlock();
        return (block.getMaterial().isSolid() || !block.isTranslucent() || block.isSolidFullCube() || block instanceof BlockLadder || block instanceof BlockCarpet || block instanceof BlockSnow || block instanceof BlockSkull) && !block.getMaterial().isLiquid() && !(block instanceof BlockContainer);
    }

    public boolean isAirBlock(Block block) {
        if (block.getMaterial().isReplaceable()) {
            return !(block instanceof BlockSnow) || !(block.getBlockBoundsMaxY() > 0.125);
        }
        return false;
    }

    @EventHandler
    private void onPostUpdate(EventPostUpdate event) {
        BlockPos underPos = new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 1.0, Minecraft.thePlayer.posZ);
        Block underBlock = Minecraft.theWorld.getBlockState(underPos).getBlock();
        BlockData data = this.getBlockData(underPos);
        if (blockCache != null) {
            if (Scaffold.mc.gameSettings.keyBindJump.pressed && ((Boolean)tower.getValue()).booleanValue()) {
                this.tower(event);
            }
            int currentSlot = Minecraft.thePlayer.inventory.currentItem;
            int slot = this.grabBlockSlot();
            Minecraft.thePlayer.inventory.currentItem = slot;
            if (this.placeBlock(BlockCache.access$2(blockCache), BlockCache.access$3(blockCache))) {
                if (((Boolean)silent.getValue()).booleanValue()) {
                    Minecraft.thePlayer.inventory.currentItem = currentSlot;
                    Minecraft.thePlayer.sendQueue.addToSendQueue(new C09PacketHeldItemChange(currentSlot));
                }
                blockCache = null;
            }
        }
    }

    public void tower(EventPostUpdate event) {
    }

    private boolean placeBlock(BlockPos pos, EnumFacing facing) {
        new net.minecraft.util.Vec3(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight(), Minecraft.thePlayer.posZ);
        if (Minecraft.playerController.onPlayerRightClick(Minecraft.thePlayer, Minecraft.theWorld, Minecraft.thePlayer.getHeldItem(), pos, facing, new Vec3(BlockCache.access$2(blockCache)).addVector(0.5, 0.5, 0.5).add(new Vec3(BlockCache.access$3(blockCache).getDirectionVec()).scale(0.5)))) {
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            if (!((Boolean)this.swing.getValue()).booleanValue()) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C0APacketAnimation());
            } else {
                Minecraft.thePlayer.swingItem();
            }
            return true;
        }
        return false;
    }

    private Vec3 grabPosition(BlockPos position, EnumFacing facing) {
        Vec3 offset = new Vec3((double)facing.getDirectionVec().getX() / 2.0, (double)facing.getDirectionVec().getY() / 2.0, (double)facing.getDirectionVec().getZ() / 2.0);
        Vec3 point = new Vec3((double)position.getX() + 0.5, (double)position.getY() + 0.5, (double)position.getZ() + 0.5);
        return point.add(offset);
    }

    public float[] getRotations(BlockPos block, EnumFacing face) {
        double x = (double)block.getX() + 0.5 - Minecraft.thePlayer.posX + (double)face.getFrontOffsetX() / 2.0;
        double z = (double)block.getZ() + 0.5 - Minecraft.thePlayer.posZ + (double)face.getFrontOffsetZ() / 2.0;
        double y = (double)block.getY() + 0.5;
        double d1 = Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight() - y;
        double d3 = MathHelper.sqrt_double(x * x + z * z);
        float yaw = (float)(Math.atan2(z, x) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float)(Math.atan2(d1, d3) * 180.0 / 3.141592653589793);
        if (yaw < 0.0f) {
            yaw += 360.0f;
        }
        return new float[]{yaw, pitch};
    }

    private BlockCache grab() {
        EnumFacing[] invert = new EnumFacing[]{EnumFacing.UP, EnumFacing.DOWN, EnumFacing.SOUTH, EnumFacing.NORTH, EnumFacing.EAST, EnumFacing.WEST};
        BlockPos position = new BlockPos(Minecraft.thePlayer.getPositionVector()).offset(EnumFacing.DOWN);
        if (!(Minecraft.theWorld.getBlockState(position).getBlock() instanceof BlockAir)) {
            return null;
        }
        EnumFacing[] var6 = EnumFacing.values();
        int var5 = var6.length;
        for (int offset = 0; offset < var5; ++offset) {
            EnumFacing offsets = var6[offset];
            BlockPos offset1 = position.offset(offsets);
            Minecraft.theWorld.getBlockState(offset1);
            if (Minecraft.theWorld.getBlockState(offset1).getBlock() instanceof BlockAir) continue;
            return new BlockCache(this, offset1, invert[offsets.ordinal()], null);
        }
        BlockPos[] var16 = new BlockPos[]{new BlockPos(-1, 0, 0), new BlockPos(0, 0, 1), new BlockPos(0, 0, -1), new BlockPos(1, 0, 0)};
        BlockPos[] var19 = var16;
        int var18 = var16.length;
        for (var5 = 0; var5 < var18; ++var5) {
            BlockPos var17 = var19[var5];
            BlockPos offsetPos = position.add(var17.getX(), 0, var17.getZ());
            if (!(Minecraft.theWorld.getBlockState(offsetPos).getBlock() instanceof BlockAir)) continue;
            for (EnumFacing facing2 : EnumFacing.values()) {
                BlockPos offset2 = offsetPos.offset(facing2);
                Minecraft.theWorld.getBlockState(offset2);
                if (Minecraft.theWorld.getBlockState(offset2).getBlock() instanceof BlockAir) continue;
                return new BlockCache(this, offset2, invert[facing2.ordinal()], null);
            }
        }
        return null;
    }

    private int grabBlockSlot() {
        for (int i = 0; i < 9; ++i) {
            ItemStack itemStack = Minecraft.thePlayer.inventory.mainInventory[i];
            if (itemStack == null || !(itemStack.getItem() instanceof ItemBlock)) continue;
            return i;
        }
        return -1;
    }

    public int getBlockCount() {
        int blockCount = 0;
        for (int i = 0; i < 45; ++i) {
            if (!Minecraft.thePlayer.inventoryContainer.getSlot(i).getHasStack()) continue;
            ItemStack is = Minecraft.thePlayer.inventoryContainer.getSlot(i).getStack();
            Item item = is.getItem();
            if (!(is.getItem() instanceof ItemBlock) || this.blacklist.contains(((ItemBlock)item).getBlock())) continue;
            blockCount += is.stackSize;
        }
        return blockCount;
    }

    private class BlockData {
        public BlockPos position;
        public EnumFacing face;

        private BlockData(BlockPos position, EnumFacing face) {
            this.position = position;
            this.face = face;
        }
    }

}

