package com.XiaoGangaDEV.module.modules.world;

import java.util.Random;

import com.XiaoGangaDEV.Client;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.misc.EventChat;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;

import net.minecraft.client.Minecraft;

public class AutoGG extends Module {
   private Mode mode = new Mode("Mode", "mode", AutoGG.AutoPlayMode.values(), AutoGG.AutoPlayMode.SkyWarsSoloNormal);
   public static Option Suffix = new Option("Suffix", "Suffix", Boolean.valueOf(true));
   public static Option AutoPlay = new Option("AutoPlay", "AutoPlay", Boolean.valueOf(false));
   public static Option LHanabi = new Option("LHanabi", "LHanabi", Boolean.valueOf(true));
   String[] LHanabiS = new String[]{"LEFgangaDEV:我妈死了", "苏辰:我是个窝囊废", "Hanabi是世界第二的客户端 Core是世界第一", "Margele在抄袭我们的源码", "Core Client Developed By XiaoMen", "Hanabi真是个废物客户端", "快来购买Core","Margele:我再进行Skid行为","ZIBLACKING开黑客了吗?"};

   public AutoGG() {
      super("AutoGG", new String[]{"AutoGG"}, ModuleType.World);
      this.addValues(new Value[]{Suffix, LHanabi, AutoPlay, this.mode});
   }

   @EventHandler
   private void onChat(EventChat e) {
      if(!e.getMessage().toLowerCase().contains("a kick occurred in your connection") && !e.getMessage().contains("浣犵殑缃戠粶杩炴帴鍑虹幇灏忛棶棰�")) {
         if(e.getMessage().contains("Winner") || e.getMessage().contains("鑳滃埄鑰�")) {
            if(!((Boolean)AutoL.nodelay.getValue()).booleanValue()) {
               if(!AutoL.timer.hasReached(3200.0D)) {
                  return;
               }

               AutoL.timer.reset();
            }

            if(((Boolean)Suffix.getValue()).booleanValue()) {
               if(((Boolean)LHanabi.getValue()).booleanValue()) {
                  Random r2 = new Random();
                  Minecraft.thePlayer.sendChatMessage("[" + Client.name + "]" + this.LHanabiS[r2.nextInt(28)]);
               } else {
                  Minecraft.thePlayer.sendChatMessage("[" + Client.name + "]GG");
               }
            } else if(((Boolean)LHanabi.getValue()).booleanValue()) {
               Random r2 = new Random();
               Minecraft.thePlayer.sendChatMessage(this.LHanabiS[r2.nextInt(28)]);
            } else {
               Minecraft.thePlayer.sendChatMessage("GG");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.Bedwars1v1) {
               Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_one");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.Bedwars2v2) {
               Minecraft.thePlayer.sendChatMessage("/play bedwars_eight_two");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.Bedwars3v3) {
               Minecraft.thePlayer.sendChatMessage("/play bedwars_four_three");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.Bedwars4v4) {
               Minecraft.thePlayer.sendChatMessage("/play bedwars_four_four");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.SkyWarsSoloNormal) {
               Minecraft.thePlayer.sendChatMessage("/play solo_normal");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.SkyWarsSoloInsane) {
               Minecraft.thePlayer.sendChatMessage("/play solo_insane");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.SkyWarsTeamsNormal) {
               Minecraft.thePlayer.sendChatMessage("/play teams_normal");
            }

            if(this.mode.getValue() == AutoGG.AutoPlayMode.SkyWarsTeamsInsane) {
               Minecraft.thePlayer.sendChatMessage("/play teams_insane");
            }
         }

      } else {
         Minecraft.thePlayer.sendChatMessage("/back");
      }
   }

   static enum AutoPlayMode {
      Bedwars4v4,
      Bedwars2v2,
      Bedwars3v3,
      Bedwars1v1,
      SkyWarsSoloNormal,
      SkyWarsSoloInsane,
      SkyWarsTeamsNormal,
      SkyWarsTeamsInsane;
   }
}
