package com.XiaoGangaDEV.module.modules.world;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.management.Notification;

import com.XiaoGangaDEV.Client;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.misc.EventChat;
import com.XiaoGangaDEV.api.events.rendering.EventRender2D;
import com.XiaoGangaDEV.api.events.world.EventTick;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.module.modules.render.UI.noti.NotificationManager;
import com.XiaoGangaDEV.module.modules.render.UI.noti.NotificationType;
import com.XiaoGangaDEV.utils.TimerUtil;

import net.minecraft.client.gui.FontRenderer;

public class StaffAlerts extends Module {

	private String[] modlist = new String[] { "Minikloon", "Bingmo", "Owenkill", "Chen_duxiu", "ʱ�����ϲ�������", "�컯������",
			"Heav3ns", "Chrisan", "��������", "Chen_xixi", "SnowDay", "Hefew", "С����", "Tanker_01", "Mxu",
			"CrazyForLove", "EnderMan001", "Jumper", "AzarelH", "Tanker"};
	private String modname;
	private TimerUtil timer = new TimerUtil();
	private ArrayList<String> offlinemod = new ArrayList();
	private ArrayList<String> onlinemod = new ArrayList();
	private Option<Boolean> showOffline = new Option<Boolean>("ShowOffline", "ShowOffline", true);
	private Option<Boolean> showOnline = new Option<Boolean>("ShowOnline", "ShowOnline", true);
	private int counter;
	private boolean isFinished;

	public StaffAlerts() {
		super("ModCheck", new String[] { "ModCheck", "ModCheck" }, ModuleType.World);
		this.addValues(this.showOffline, this.showOnline);
	}

	@EventHandler
	public void onRender(EventRender2D e) {
		FontRenderer font = mc.fontRendererObj;
		List<String> listArray = Arrays.asList(modlist);
		listArray.sort((o1, o2) -> {
			return font.getStringWidth(o2) - font.getStringWidth(o1);
		});
		int counter2 = 0;
		for (String mods : listArray) {
			if (offlinemod.contains(mods) && showOffline.getValue()) {
				font.drawStringWithShadow(mods, 5, 100 + counter2 * 10, Color.RED.getRGB());
				counter2++;
			}
			if (onlinemod.contains(mods) && showOnline.getValue()) {
				font.drawStringWithShadow(mods, 5, 100 + counter2 * 10, Color.GREEN.getRGB());
				counter2++;
			}

		}
	}

	@EventHandler
	public void onChat(EventChat e) {
		if (e.getMessage().contains("������Ҳ����ߣ�")) {
			e.setCancelled(true);
			if (onlinemod.contains(modname)) {
				onlinemod.remove(modname);
				offlinemod.add(modname);
				return;
			}
			if (!offlinemod.contains(modname)) {
				offlinemod.add(modname);
			}
		}
		if (e.getMessage().contains("You cannot message this player.")) {
			e.setCancelled(true);
			if (offlinemod.contains(modname)) {
				offlinemod.remove(modname);
				onlinemod.add(modname);
				return;
			}
			if (!onlinemod.contains(modname)) {
				onlinemod.add(modname);
			}
		}
		if (e.getMessage().contains("������� [�ͷ�] " + modname + " ����Ϊʱ 5 ���ӵ����졣ʹ��ָ�� /chat a ��������")) {
			e.setCancelled(true);
			if (offlinemod.contains(modname)) {
				offlinemod.remove(modname);
				onlinemod.add(modname);
				return;
			}
			if (!onlinemod.contains(modname)) {
				onlinemod.add(modname);
			}
			this.mc.thePlayer.sendChatMessage("/chat a");
		}
		if (e.getMessage().contains("�Ҳ�����Ϊ\"" + modname + "\" �����")) {
			e.setCancelled(true);
		}
	}

	@EventHandler
	public void onTick(EventTick e) {
		if (timer.hasReached(isFinished ? 10000L : 5500L)) {
			if (counter >= modlist.length) {
				counter = -1;
				if (!isFinished) {
					isFinished = true;
				}

			}
			counter += 1;
			modname = modlist[counter];
			mc.thePlayer.sendChatMessage("/t " + modname);
			timer.reset();
		}
	}

	}

