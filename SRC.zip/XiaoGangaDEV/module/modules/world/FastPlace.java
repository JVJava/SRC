/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.world;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventTick;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;

public class FastPlace
extends Module {
    public FastPlace() {
        super("FastPlace", new String[]{"fplace", "fc"}, ModuleType.World);
        this.setColor(new Color(226, 197, 78).getRGB());
    }

    @EventHandler
    private void onTick(EventTick e) {
        this.mc.rightClickDelayTimer = 0;
    }
}

