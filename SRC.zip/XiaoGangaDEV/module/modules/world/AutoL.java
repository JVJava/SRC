package com.XiaoGangaDEV.module.modules.world;

import java.util.Random;

import com.XiaoGangaDEV.Client;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.misc.EventChat;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.TimerUtil;

import net.minecraft.client.Minecraft;

public class AutoL extends Module {
   public static Option autowdr = new Option("Watchdog", "Watchdog", Boolean.valueOf(true));
   public static Option onlyWDR = new Option("onlyWDR", "onlyWDR", Boolean.valueOf(true));
   public static Option nodelay = new Option("nodelay", "nodelay", Boolean.valueOf(true));
   public static Option ClientInfo = new Option("LHanabi", "LHanabi", Boolean.valueOf(true));
   public static TimerUtil timer = new TimerUtil();
   String[] LHanabiS = new String[]{"LEFgangaDEV:我妈死了", "苏辰:我是个窝囊废", "Hanabi是世界第二的客户端 Core是世界第一", "Margele在抄袭我们的源码", "Core Client Developed By XiaoMen", "Hanabi真是个废物客户端", "快来购买Core","Margele:我再进行Skid行为"};

   public AutoL() {
      super("AutoL", new String[]{"TPAccept, autotp"}, ModuleType.World);
      this.addValues(new Value[]{autowdr, ClientInfo, nodelay, onlyWDR});
   }

   public void onDisable() {
   }

   @EventHandler
   private void onChat(EventChat e10) {
      if(e10.getMessage().contains("was killed by " + Minecraft.thePlayer.getName() + ".") || e10.getMessage().contains("was thrown into the void by " + Minecraft.thePlayer.getName() + ".") || e10.getMessage().contains("was thrown off a cliff by " + Minecraft.thePlayer.getName() + ".") || e10.getMessage().contains("琚�" + Minecraft.thePlayer.getName() + "鍑绘潃") || e10.getMessage().contains("琚�" + Minecraft.thePlayer.getName() + "鎵斾笅浜嗚櫄绌�") || e10.getMessage().contains(" 琚嚮鏉�锛屽嚮鏉�鑰咃細 " + Minecraft.thePlayer.getName()) || e10.getMessage().contains(" 琚嚮鍊掞紝鍑绘潃鑰咃細 " + Minecraft.thePlayer.getName()) || e10.getMessage().contains(" 琚墧涓嬫偓宕栵紝鍑绘潃鑰咃細 " + Minecraft.thePlayer.getName()) || e10.getMessage().contains(" 琚墧涓嬭櫄绌猴紝鍑绘潃鑰咃細 " + Minecraft.thePlayer.getName()) || e10.getMessage().contains("琚�" + Minecraft.thePlayer.getName() + "鎵斾笅浜嗘偓宕栥��")) {
         if(!((Boolean)nodelay.getValue()).booleanValue() && !timer.hasReached(3200.0D)) {
            return;
         }

         timer.reset();
         if(((Boolean)onlyWDR.getValue()).booleanValue()) {
            Minecraft.thePlayer.sendChatMessage("/wdr " + e10.getMessage().split("琚�")[0] + " ka ac reach speed fly anti-kb");
            return;
         }

         if(((Boolean)ClientInfo.getValue()).booleanValue()) {
            Random r2 = new Random();
            Minecraft.thePlayer.sendChatMessage("[" + Client.name + "] L " + e10.getMessage().split("琚�")[0] + " " + this.LHanabiS[r2.nextInt(28)]);
         } else {
            Minecraft.thePlayer.sendChatMessage("[" + Client.name + "] L " + e10.getMessage().split("琚�")[0]);
         }

         if(((Boolean)autowdr.getValue()).booleanValue()) {
            Minecraft.thePlayer.sendChatMessage("/wdr " + e10.getMessage().split("琚�")[0] + " ka ac reach speed fly anti-kb");
         }
      }

   }

   public static String sendGet(String string) {
      return null;
   }

   public static String getRandomString(double d) {
      return null;
   }
}
