/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.player;

import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import java.awt.Color;
import java.util.Random;

public class NoStrike
extends Module {
    public NoStrike() {
        super("NoStrike", new String[]{"antistrike"}, ModuleType.Player);
        this.setColor(new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255)).getRGB());
    }
}

