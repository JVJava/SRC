/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.player;

import java.awt.Color;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPacketSend;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.darkmagician6.eventapi.EventTarget;

import net.minecraft.client.Minecraft;
import net.minecraft.init.Blocks;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.util.BlockPos;

public class NoFall
extends Module {
    public Mode<Enum> mode = new Mode("mode", "mode", (Enum[])Nofallmode.values(), (Enum)Nofallmode.NORMAL);

    public NoFall() {
        super("NoFall", new String[]{"Nofalldamage"}, ModuleType.World);
        this.setColor(new Color(242, 137, 73).getRGB());
        this.addValues(this.mode);
    }

    @EventHandler
    private void onUpdate(EventPreUpdate e2) {
        if (this.mode.getValue() == Nofallmode.Hypixel2) {
			   if (this.mc.thePlayer.fallDistance > 2.0F) {
				   this.mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
				   this.mc.thePlayer.fallDistance = 0.0F;
			   }
        }
    }

    @EventTarget
	   public void onPacket(EventPacket e) {
    	if (this.mode.getValue() == Nofallmode.Hypixel) {
			   if(e.getPacket() instanceof C03PacketPlayer) {
					if(mc.thePlayer.fallDistance > 3.0F) {
						((C03PacketPlayer)e.packet).onGround = true;
					}
			   }
		   }
    }
    
    @EventHandler
    public void packetSend(EventPacketSend event) {
        if (this.mode.getValue() == Nofallmode.NORMAL && event.getPacket() instanceof C03PacketPlayer && Minecraft.thePlayer.fallDistance > 3.0f) {
            C03PacketPlayer packet = (C03PacketPlayer)event.getPacket();
            packet.onGround = true;
        }
        if (this.mode.getValue() == Nofallmode.AAC && Minecraft.theWorld.getBlockState(new BlockPos(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 2.0, Minecraft.thePlayer.posZ)).getBlock() != Blocks.air && Minecraft.thePlayer.fallDistance >= 3.0f) {
            Minecraft.thePlayer.setPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY - 2.5, Minecraft.thePlayer.posZ);
            Minecraft.thePlayer.motionX *= 0.0;
            Minecraft.thePlayer.fallDistance = 0.0f;
            Minecraft.thePlayer.motionZ *= 0.0;
        }
    }

    static enum Nofallmode {
        Hypixel,
        Hypixel2,
        NORMAL,
        AAC;

    }

}

