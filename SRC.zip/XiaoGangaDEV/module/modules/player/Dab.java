package com.XiaoGangaDEV.module.modules.player;

import java.awt.Color;

import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;

public class Dab extends Module {
   public Dab() {
      super("Dab", new String[]{"dab"}, ModuleType.Player);
      this.setColor((new Color(random.nextInt(255), random.nextInt(255), random.nextInt(255))).getRGB());
      this.setRemoved(false);
   }
}
