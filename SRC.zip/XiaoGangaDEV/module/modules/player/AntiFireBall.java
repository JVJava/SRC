package com.XiaoGangaDEV.module.modules.player;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.math.RotationUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.network.play.client.C02PacketUseEntity;

public class AntiFireBall extends Module {
   private Numbers range = new Numbers("range", "range", Double.valueOf(4.5D), Double.valueOf(1.0D), Double.valueOf(6.0D), Double.valueOf(0.1D));
   private Option rot = new Option("rot", "rot", Boolean.valueOf(true));

   public AntiFireBall() {
      super("AntiFireball", new String[]{"AntiFireball"}, ModuleType.Player);
      this.addValues(new Value[]{this.range, this.rot});
   }

   @EventHandler
   private void EventPreUpdate(EventPreUpdate event) {
      for(Entity entity : Minecraft.theWorld.loadedEntityList) {
         if(entity instanceof EntityFireball) {
            double rangeToEntity = (double)Minecraft.thePlayer.getDistanceToEntity(entity);
            if(rangeToEntity <= ((Double)this.range.getValue()).doubleValue()) {
               Minecraft.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(entity, C02PacketUseEntity.Action.ATTACK));
               if(((Boolean)this.rot.getValue()).booleanValue()) {
                  float[] rotation = RotationUtil.getRotations(entity, 4);
                  event.setYaw(rotation[0]);
                  event.setPitch(rotation[1]);
               }
            }
         }
      }

   }
}
