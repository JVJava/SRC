/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.player;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import java.awt.Color;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

public class Bobbing
extends Module {
    private Numbers<Double> boob = new Numbers<Double>("Amount", "Amount", 1.0, 0.1, 5.0, 0.5);

    public Bobbing() {
        super("Bobbing+", new String[]{"bobbing+"}, ModuleType.Player);
        this.addValues(this.boob);
    }

    @EventHandler
    public void onUpdate(EventPreUpdate event) {
        this.setColor(new Color(20, 200, 100).getRGB());
        if (this.mc.thePlayer.onGround) {
            this.mc.thePlayer.cameraYaw = (float)(0.09090908616781235 * this.boob.getValue());
        }
    }
}

