package com.XiaoGangaDEV.module.modules.combat;

import com.XiaoGangaDEV.api.Event;

public class CancelableEvent extends Event {
   private boolean canceled;

   public boolean isCanceled() {
      return this.canceled;
   }

   public void setCanceled(boolean canceled) {
      this.canceled = canceled;
   }
}
