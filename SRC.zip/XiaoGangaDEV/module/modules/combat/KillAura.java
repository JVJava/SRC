/*
 * Decompiled with CFR 0_132 Helper by Lightcolour E-mail wyy-666@hotmail.com.
 * 
 * Could not load the following classes:
 *  org.lwjgl.opengl.GL11
 */
package com.XiaoGangaDEV.module.modules.combat;

import java.util.Random;

import javax.vecmath.Vector2f;

import org.lwjgl.opengl.GL11;

import com.XiaoGangaDEV.Client;
import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.rendering.EventRender2D;
import com.XiaoGangaDEV.api.events.rendering.EventRender3D;
import com.XiaoGangaDEV.api.events.world.EventPostUpdate;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.management.FriendManager;
import com.XiaoGangaDEV.management.ModuleManager;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.module.modules.player.Teams;
import com.XiaoGangaDEV.utils.CombatUtil;
import com.XiaoGangaDEV.utils.RotationUtils;
import com.XiaoGangaDEV.utils.TimerUtil;
import com.XiaoGangaDEV.utils.math.Angle;
import com.XiaoGangaDEV.utils.math.AngleUtility;
import com.XiaoGangaDEV.utils.math.RotationUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.passive.EntityBat;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

public class KillAura
extends Module {
    public Vector2f lastAngle = new Vector2f(0.0f, 0.0f);
    private Mode<Enum> espmode = new Mode("ESP", "ESP", (Enum[])EMode.values(), (Enum)EMode.None);
    private static Numbers<Double> cps = new Numbers<Double>("Cps", "Cps", 10.0, 1.0, 20.0, 0.5);
    public static Numbers<Double> reach = new Numbers<Double>("Reach", "Reach", 4.5, 1.0, 6.0, 0.1);
    public static Numbers<Double> turnspeed = new Numbers<Double>("Turnspeed", "Turnspeed", 90.0, 0.0, 360.0, 1.0);
    private Numbers<Double> blockreach = new Numbers<Double>("BlockReach", "BlockReach", 6.0, 1.0, 10.0, 0.1);
    private Option<Boolean> blocking = new Option<Boolean>("Autoblock", "Autoblock", true);
    private Option<Boolean> players = new Option<Boolean>("Players", "Players", true);
    private Option<Boolean> animals = new Option<Boolean>("Animals", "Animals", false);
    private Option<Boolean> village = new Option<Boolean>("Village", "Village", false);
    private Option<Boolean> mobs = new Option<Boolean>("Mobs", "Mobs", false);
    private Option<Boolean> invis = new Option<Boolean>("Invisibles", "Invisibles", false);
    private Option<Boolean> targethp = new Option<Boolean>("targetHP", "targetHP", false);
    private Option<Boolean> look = new Option<Boolean>("LookView", "LookView", false);
    private Mode ro = new Mode("RotateHeadMode", "RotateHeadMode", (Enum[])RMode.values(), (Enum)RMode.Client);
    public static EntityLivingBase curTarget;
    public static float sYaw;
    public static float sPitch;
    public static float aacB;
    public EntityLivingBase blocktarget;
    public TimerUtil timerUtil = new TimerUtil();
    public boolean isBlock;
    public boolean ready;
    public static float[] facing;
    private float[] facing0;
    private float[] facing1;
    private float[] facing2;
    private float[] facing3;
    private Vector2f lastAngles = new Vector2f(0.0f, 0.0f);

    public KillAura() {
        super("Killaura", new String[]{"ka", "aura", "killa"}, ModuleType.Combat);
        this.addValues(this.ro, this.espmode, cps, reach, this.blockreach, turnspeed, this.blocking, this.players, this.animals, this.village, this.mobs, this.invis, this.targethp, this.look);
    }

    @Override
    public void onEnable() {
        curTarget = null;
        sYaw = Minecraft.thePlayer.rotationYaw;
        sPitch = Minecraft.thePlayer.rotationPitch;
    }

    public Angle Rotate() {
        AngleUtility angleUtility = new AngleUtility(9.0f, 90.0f, 3.0f, 30.0f);
        Vector3<Double> enemyCoords = new Vector3<Double>(KillAura.curTarget.posX, KillAura.curTarget.posY - (double)curTarget.getEyeHeight() / 2.0, KillAura.curTarget.posZ);
        Vector3<Double> myCoords = new Vector3<Double>(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY, Minecraft.thePlayer.posZ);
        Angle dstAngle = angleUtility.calculateAngle(enemyCoords, myCoords);
        Angle srcAngle = new Angle(Float.valueOf(CombatUtil.getRotations(curTarget)[0]), Float.valueOf(CombatUtil.getRotations(curTarget)[1]));
        Angle smoothedAngle1 = angleUtility.smoothAngle(dstAngle, dstAngle);
        return smoothedAngle1;
    }

    @EventHandler
    public void onPre(EventPreUpdate e) {
        this.setSuffix("Switch");
        curTarget = this.getcurTarget(reach.getValue());
        this.blocktarget = this.getcurTargetBlock(this.blockreach.getValue());
        if (this.blocktarget != null) {
            if (this.canBlock() && !this.isBlock) {
                this.StartBlock();
            }
        } else if (this.canBlock() && this.isBlock) {
            this.StopBlock();
        }
        if (curTarget != null) {
            int rot2;
            double range1 = reach.getValue();
            float targetYaw = MathHelper.clamp_float(RotationUtils.getYawChangeGiven(KillAura.curTarget.posX, KillAura.curTarget.posZ, this.lastAngles.x) + KillAura.randomfloat(3.23f, -3.23f), -180.0f, 180.0f);
            float[] NeedRotation = RotationUtils.getRotationsForAura(curTarget, range1 + 3.0);
            if (NeedRotation == null) {
                return;
            }
            float[] rot = RotationUtil.exgetRotations(curTarget);
            float rot1 = MathHelper.clamp_float(RotationUtil.getYawChangeGiven(KillAura.curTarget.posX, KillAura.curTarget.posZ, this.lastAngle.x), -180.0f, 180.0f);
            if (rot1 > (float)(rot2 = (int)(turnspeed.getValue() - 20.0 + (double)random.nextInt(30)))) {
                rot1 = rot2;
            } else if (rot1 < (float)(- rot2)) {
                rot1 = - rot2;
            }
            if (this.ro.getValue() == RMode.Mode1) {
                e.setYaw(this.lastAngles.x += targetYaw / 1.03f);
                e.setPitch(NeedRotation[1] + KillAura.randomfloat(0.5f, -0.5f));
                sYaw = NeedRotation[0];
                sPitch = NeedRotation[1];
            }
            if (this.ro.getValue() == RMode.Normal) {
                Random rand = new Random();
                this.facing0 = KillAura.getRotationsNeededBlock(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                this.facing1 = KillAura.getRotationFromPosition(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                this.facing2 = KillAura.getRotationsNeededBlock(KillAura.curTarget.posX, KillAura.curTarget.posY, KillAura.curTarget.posZ);
                this.facing3 = KillAura.getRotations(curTarget);
                int i = 0;
                while (i <= 3) {
                    switch (KillAura.randomNumber(0.0, i)) {
                        case 0: {
                            facing = this.facing0;
                        }
                        case 1: {
                            facing = this.facing1;
                        }
                        case 2: {
                            facing = this.facing2;
                        }
                        case 3: {
                            facing = this.facing3;
                        }
                    }
                    ++i;
                }
                if (facing.length >= 0) {
                    e.setYaw(facing[0]);
                    e.setPitch(facing[1]);
                }
                if (curTarget != null) {
                    Minecraft.thePlayer.renderYawOffset = facing[0];
                    Minecraft.thePlayer.rotationYawHead = facing[0];
                }
                int maxAngleStep = turnspeed.getValue().intValue();
                float[] rotations = RotationUtil.faceTarget(curTarget, 1000.0f, 1000.0f, false);
                int xz = (int)((double)KillAura.randomNumber(maxAngleStep, maxAngleStep) / 100.0);
                float targetYaw1 = RotationUtils.getYawChange(sYaw, KillAura.curTarget.posX, KillAura.curTarget.posZ);
                if (targetYaw1 > (float)maxAngleStep) {
                    targetYaw1 = maxAngleStep;
                } else if (targetYaw1 < (float)(- maxAngleStep)) {
                    targetYaw1 = maxAngleStep;
                } else if (targetYaw1 <= (float)(- maxAngleStep) && targetYaw1 < (float)maxAngleStep) {
                    targetYaw1 += (float)maxAngleStep;
                }
                targetYaw1 = targetYaw1 == (float)maxAngleStep ? (targetYaw1 += (float)maxAngleStep) : (float)((int)targetYaw1);
                float yawFactor = targetYaw1 / 1.1f;
                float POSTrotat = sYaw += yawFactor;
                if (KillAura.curTarget.hurtTime < 0) {
                    sYaw = 0.0f;
                    POSTrotat = rotations[0];
                }
                e.setYaw(POSTrotat + (float)(random.nextInt(200) > 100 ? -3 : 3));
                e.setPitch(rotations[1] + (float)random.nextInt(5));
            }
            if (this.look.getValue().booleanValue()) {
                e.setRotations(rot, false);
            }
            this.ready = true;
        } else {
            this.ready = false;
        }
    }

    public static float[] getRotations(EntityLivingBase curTarget2) {
        if (curTarget2 == null) {
            return null;
        }
        double diffX = curTarget2.posX - Minecraft.thePlayer.posX;
        double diffZ = curTarget2.posZ - Minecraft.thePlayer.posZ;
        double diffY = curTarget2.posY - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight());
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float)((- Math.atan2(diffY, dist)) * 180.0 / 3.141592653589793);
        return new float[]{yaw, pitch};
    }

    private static int randomNumber(double min, double max) {
        Random random = new Random();
        return (int)(min + random.nextDouble() * (max - min));
    }

    public static float[] getRotationsNeededBlock(double x, double y, double z) {
        double diffX = x - Minecraft.thePlayer.posX;
        double diffZ = z - Minecraft.thePlayer.posZ;
        double diffY = y - Minecraft.thePlayer.posY - 0.2;
        double dist = MathHelper.sqrt_double(diffX * diffX + diffZ * diffZ);
        float yaw = (float)(Math.atan2(diffZ, diffX) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float)((- Math.atan2(diffY, dist)) * 180.0 / 3.141592653589793);
        float[] array = new float[2];
        int n = 0;
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        float n2 = yaw;
        array[n] = rotationYaw + MathHelper.wrapAngleTo180_float(n2 - Minecraft.thePlayer.rotationYaw);
        int n3 = 1;
        float rotationPitch = Minecraft.thePlayer.rotationPitch;
        float n4 = pitch;
        array[n3] = rotationPitch + MathHelper.wrapAngleTo180_float(n4 - Minecraft.thePlayer.rotationPitch);
        return array;
    }

    public static float[] getRotationFromPosition(double x, double z, double y) {
        double xDiff = x - Minecraft.thePlayer.posX;
        double zDiff = z - Minecraft.thePlayer.posZ;
        double yDiff = y - Minecraft.thePlayer.posY - 0.4;
        double dist = MathHelper.sqrt_double(xDiff * xDiff + zDiff * zDiff);
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        float pitch = (float)((- Math.atan2(yDiff, dist)) * 180.0 / 3.141592653589793);
        float[] array = new float[2];
        int n = 0;
        float rotationYaw = Minecraft.thePlayer.rotationYaw;
        float n2 = yaw;
        array[n] = rotationYaw + MathHelper.wrapAngleTo180_float(n2 - Minecraft.thePlayer.rotationYaw);
        int n3 = 1;
        float rotationPitch = Minecraft.thePlayer.rotationPitch;
        float n4 = pitch;
        array[n3] = rotationPitch + MathHelper.wrapAngleTo180_float(n4 - Minecraft.thePlayer.rotationPitch);
        return array;
    }

    public static float randomfloat(float max, float min) {
        return min + (float)Math.random() * (max - min);
    }

    @EventHandler
    public void onPost(EventPostUpdate e) {
        if (curTarget != null && this.ready && this.timerUtil.delay((long)(1000.0 / cps.getValue()))) {
            if (this.canBlock() && this.isBlock) {
                this.StopBlock();
            }
            this.attack(curTarget);
            if (this.canBlock() && !this.isBlock) {
                this.StartBlock();
            }
            this.timerUtil.reset();
        }
    }

    @Override
    public void onDisable() {
        if (this.canBlock() && this.isBlock) {
            this.StopBlock();
        }
        this.ready = false;
        curTarget = null;
        this.blocktarget = null;
    }

    public boolean canBlock() {
        if (this.blocking.getValue().booleanValue() && Minecraft.thePlayer.getHeldItem() != null && Minecraft.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemSword) {
            return true;
        }
        return false;
    }

    public void attack(Entity entity) {
        Minecraft.thePlayer.swingItem();
        Minecraft.playerController.attackEntity(Minecraft.thePlayer, entity);
    }

    private void StartBlock() {
        Minecraft.thePlayer.itemInUseCount = Minecraft.thePlayer.getHeldItem().getMaxItemUseDuration();
        Minecraft.playerController.netClientHandler.addToSendQueue(new C08PacketPlayerBlockPlacement(Minecraft.thePlayer.inventory.getCurrentItem()));
        this.isBlock = true;
    }

    private void StopBlock() {
        Minecraft.playerController.netClientHandler.addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
        Minecraft.thePlayer.itemInUseCount = 0;
        this.isBlock = false;
    }

    public EntityLivingBase getcurTarget(double range) {
        double setrange = range;
        EntityLivingBase returncurTarget = null;
        for (Entity entity : Minecraft.theWorld.loadedEntityList) {
            double ranges;
            if (!(entity instanceof EntityLivingBase) || !this.cancurTarget(entity) || (ranges = (double)Minecraft.thePlayer.getDistanceToEntity(entity)) > setrange) continue;
            setrange = ranges;
            returncurTarget = (EntityLivingBase)entity;
        }
        return returncurTarget;
    }

    public EntityLivingBase getcurTargetBlock(double range) {
        double setrange = range;
        EntityLivingBase returncurTarget = null;
        for (Entity entity : Minecraft.theWorld.loadedEntityList) {
            double ranges;
            if (!(entity instanceof EntityLivingBase) || !this.cancurTargetBlock(entity) || (ranges = (double)Minecraft.thePlayer.getDistanceToEntity(entity)) > setrange) continue;
            setrange = ranges;
            returncurTarget = (EntityLivingBase)entity;
        }
        return returncurTarget;
    }

    public boolean cancurTarget(Entity entity) {
        Client.getModuleManager();
        AntiBot ab = (AntiBot)ModuleManager.getModuleByClass(AntiBot.class);
        if (entity.getName().contains("\u00a7")) {
            Client.getModuleManager();
            if (ModuleManager.getModuleByClass(AntiBot.class).isEnabled()) {
                return false;
            }
        }
        if (Teams.isOnSameTeam(entity)) {
            Client.getModuleManager();
            if (ModuleManager.getModuleByClass(Teams.class).isEnabled()) {
                return false;
            }
        }
        if (FriendManager.isFriend(entity.getName())) {
            return false;
        }
        if (ab.isServerBot(entity)) {
            return false;
        }
        if (entity instanceof EntityPlayer && !this.players.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityAnimal && !this.animals.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityMob && !this.mobs.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityVillager && !this.village.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityBat && !this.mobs.getValue().booleanValue()) {
            return false;
        }
        if (entity.isInvisible() && !this.invis.getValue().booleanValue()) {
            return false;
        }
        if (entity != Minecraft.thePlayer && entity.isEntityAlive() && (double)Minecraft.thePlayer.getDistanceToEntity(entity) <= reach.getValue()) {
            return true;
        }
        return false;
    }

    public boolean cancurTargetBlock(Entity entity) {
        if (entity.getName().contains("\u00a7")) {
            Client.getModuleManager();
            if (ModuleManager.getModuleByClass(AntiBot.class).isEnabled()) {
                return false;
            }
        }
        if (Teams.isOnSameTeam(entity)) {
            Client.getModuleManager();
            if (ModuleManager.getModuleByClass(Teams.class).isEnabled()) {
                return false;
            }
        }
        if (FriendManager.isFriend(entity.getName())) {
            return false;
        }
        if (entity instanceof EntityPlayer && !this.players.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityAnimal && !this.animals.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityMob && !this.mobs.getValue().booleanValue()) {
            return false;
        }
        if (entity instanceof EntityVillager && !this.village.getValue().booleanValue()) {
            return false;
        }
        if (entity.isInvisible() && !this.invis.getValue().booleanValue()) {
            return false;
        }
        if (entity != Minecraft.thePlayer && entity.isEntityAlive() && (double)Minecraft.thePlayer.getDistanceToEntity(entity) <= this.blockreach.getValue()) {
            return true;
        }
        return false;
    }

    @EventHandler
    public void curTargetHud(EventRender2D event) {
        if (this.targethp.getValue().booleanValue()) {
            ScaledResolution sr2 = new ScaledResolution(mc);
            if (curTarget != null) {
                GL11.glColor4f((float)1.0f, (float)1.0f, (float)1.0f, (float)1.0f);
                FontRenderer font = KillAura.mc.fontRendererObj;
                font.drawStringWithShadow(curTarget.getName(), sr2.getScaledWidth() / 2 - font.getStringWidth(curTarget.getName()) / 2, sr2.getScaledHeight() / 2 - 30, 16777215);
                mc.getTextureManager().bindTexture(new ResourceLocation("textures/gui/icons.png"));
                int i2 = 0;
                while ((float)i2 < curTarget.getMaxHealth() / 2.0f) {
                    KillAura.mc.ingameGUI.drawTexturedModalRect((float)(sr2.getScaledWidth() / 2) - curTarget.getMaxHealth() / 2.0f * 10.0f / 2.0f + (float)(i2 * 10), (float)(sr2.getScaledHeight() / 2 - 20), 16, 0, 9, 9);
                    ++i2;
                }
                i2 = 0;
                while ((float)i2 < curTarget.getHealth() / 2.0f) {
                    KillAura.mc.ingameGUI.drawTexturedModalRect((float)(sr2.getScaledWidth() / 2) - curTarget.getMaxHealth() / 2.0f * 10.0f / 2.0f + (float)(i2 * 10), (float)(sr2.getScaledHeight() / 2 - 20), 52, 0, 9, 9);
                    ++i2;
                }
            }
        }
    }

    @EventHandler
    private void render(EventRender3D e) {
    }

   public static enum EMode {
        None,
        Box,
        FlatBox;
        


    }

  public  static enum RMode {
        Normal,
     Mode1;
        


    }

}

