/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.combat;


import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPacketRecieve;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Mode;
import com.XiaoGangaDEV.management.ModuleManager;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.module.modules.movement.Speed;
import com.XiaoGangaDEV.utils.Helper;
import com.XiaoGangaDEV.utils.math.MathUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;

public class Criticals
extends Module {
    public Mode<Enum> mode = new Mode("Mode", "Mode", (Enum[])CritMode.values(), (Enum)CritMode.Packet);
    public Timer timer = new Timer();
    private EventPacketRecieve event;

    public Criticals() {
        super("Criticals", new String[]{"Criticals"}, ModuleType.Combat);
        this.addValues(this.mode);
    }

    @EventHandler
    public void EventPreUpdate(EventPreUpdate e) {
        this.setSuffix(this.mode.getValue());
    }

    private boolean canCrit() {
        return Minecraft.thePlayer.onGround && !Minecraft.thePlayer.isInWater();
    }

    void packetCrit() {
        if (Timer.hasReached(Helper.onServer("hypixel") ? 0 : 200) && this.mode.getValue() == CritMode.Packet && this.canCrit()) {
            C02PacketUseEntity packet;
            double[] offsets = new double[]{0.025, 0.0, 1.0E-4, 0.0};
            for (int i = 0; i < offsets.length; ++i) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + offsets[i], Minecraft.thePlayer.posZ, false));
            }
            Speed speed = (Speed)ModuleManager.getModuleByClass(Speed.class);
            if (speed.isEnabled() && this.event.getPacket() != null && (packet = (C02PacketUseEntity)this.event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 0.1625, Minecraft.thePlayer.posZ, false));
            }
            Timer.reset();
        }
    }

    public void exCrit() {
        if (this.canCrit() && this.mode.getValue() == CritMode.Exhibobo) {
            double offset1 = Criticals.randomNumber(-9999, 9999) / 10000000;
            double offset2 = Criticals.randomNumber(-9999, 9999) / 1000000000;
            for (double offset : new double[]{0.0624218713251234 + offset1, 0.0, 1.0834773E-5 + offset2, 0.0}) {
                Minecraft var10000 = mc;
                Minecraft var10003 = mc;
                Minecraft var10004 = mc;
                double var10 = Minecraft.thePlayer.posY + offset;
                Minecraft var10005 = mc;
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, var10, Minecraft.thePlayer.posZ, false));
            }
        }
    }

    public void hypixelCrit() {
        if (this.mode.getValue() == CritMode.Hypixel && this.canCrit() && Timer.hasReached(200L)) {
            C02PacketUseEntity packet;
            Speed speed = (Speed)ModuleManager.getModuleByClass(Speed.class);
            if (speed.isEnabled() && (packet = (C02PacketUseEntity)this.event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 0.1625, Minecraft.thePlayer.posZ, false));
            }
            for (double offset : new double[]{0.06142999976873398, 0.0, 0.012511000037193298, 0.0}) {
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + offset, Minecraft.thePlayer.posZ, false));
            }
            Timer.reset();
        }
    }

    @EventHandler
    public void EventAttack(EventAttack e) {
        if (this.mode.getValue() == CritMode.RemixPacket) {
            this.RemixCrits();
        }
        if (this.mode.getValue() == CritMode.Hypixel) {
            this.hypixelCrit();
        }
        if (this.mode.getValue() == CritMode.Packet) {
            this.packetCrit();
        }
        if (this.mode.getValue() == CritMode.Exhibobo) {
            this.exCrit();
        }
    }

    void RemixCrits() {
        if (Timer.hasReached(500L) && Criticals.isOnGround(0.072) && this.canCrit() && this.mode.getValue() == CritMode.RemixPacket) {
            double[] offsets;
            double[] var5 = offsets = new double[]{0.051 * MathUtil.randomFloat(1.08f, 1.1f), 0.0, 0.0125 * MathUtil.randomFloat(1.01f, 1.07f), 0.0};
            int var6 = offsets.length;
            for (int var7 = 0; var7 < var6; ++var7) {
                double v = var5[var7];
                System.out.print("C08");
                Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + v, Minecraft.thePlayer.posZ, false));
            }
            Timer.reset();
        }
    }

    public static boolean isOnGround(double height) {
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        return !Minecraft.theWorld.getCollidingBoundingBoxes(Minecraft.thePlayer, Minecraft.thePlayer.getEntityBoundingBox().offset(0.0, -height, 0.0)).isEmpty();
    }

    public void hypixelCrit2() {
        C02PacketUseEntity packet;
        if (Timer.hasReached(Helper.onServer("hypixel") ? 0 : 10) && this.mode.getValue() == CritMode.HypixelPacket && this.canCrit() && (packet = (C02PacketUseEntity)this.event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK) {
            Minecraft.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer.C04PacketPlayerPosition(Minecraft.thePlayer.posX, Minecraft.thePlayer.posY + 0.1625, Minecraft.thePlayer.posZ, false));
        }
    }

    private static int randomNumber(int max, int min) {
        return (int)(Math.random() * (double)(max - min)) + min;
    }

    static enum CritMode {
        Hypixel,
        HypixelPacket,
        Packet,
        RemixPacket,
        Exhibobo;

    }

}

