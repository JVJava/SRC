package com.XiaoGangaDEV.module.modules.combat;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.value.Numbers;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.Wrapper;

import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.client.C03PacketPlayer;

public class MoreKnockBack extends Module {
   private Numbers packets = new Numbers("Packets", "packets", Double.valueOf(100.0D), Double.valueOf(50.0D), Double.valueOf(2000.0D), Double.valueOf(50.0D));
   private EntityPlayer entity;

   public MoreKnockBack() {
      super("MoreKnockBack", new String[]{"superknockback"}, ModuleType.Combat);
      this.addValues(new Value[]{this.packets});
   }

   @EventHandler
   public void onAttack(EventAttack e) {
      if(Minecraft.thePlayer.getDistanceToEntity(e.getEntity()) <= 1.0F || Minecraft.thePlayer.getEntityBoundingBox().intersectsWith(e.getEntity().getEntityBoundingBox())) {
         for(int i = 0; (double)i < ((Double)this.packets.getValue()).doubleValue(); ++i) {
            if(Minecraft.thePlayer.onGround) {
               Wrapper.sendPacketInQueue(new C03PacketPlayer());
            }
         }
      }

   }
}
