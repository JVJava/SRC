/*
 * Decompiled with CFR 0_132 Helper by Lightcolour E-mail wyy-666@hotmail.com.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Ordering
 *  com.mojang.authlib.GameProfile
 */
package com.XiaoGangaDEV.module.modules.combat;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.Helper;
import com.XiaoGangaDEV.utils.TimerUtil;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiPlayerTabOverlay;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.EnumChatFormatting;

public class AntiBot
extends Module {
    public static List<Entity> invaild = new ArrayList<Entity>();
    TimerUtil timer = new TimerUtil();

    public AntiBot() {
        super("Anti Bot", new String[]{"AntiBot", "botkiller"}, ModuleType.Combat);
        this.setColor(new Color(217, 149, 251).getRGB());
    }

    @Override
    public void onEnable() {
        invaild.clear();
    }

    @EventHandler
    public void onUpdate(EventPreUpdate e) {
        this.setSuffix("Hypixel");
        if (invaild.size() >= 1 && this.timer.hasReached(1500.0)) {
            invaild.clear();
            this.timer.reset();
        }
        for (Entity o : Minecraft.theWorld.getLoadedEntityList()) {
            EntityLivingBase ent;
            if (o instanceof EntityPlayer) {
                ent = (EntityPlayer)o;
                String format = ent.getDisplayName().getFormattedText();
                String custom = ent.getCustomNameTag();
                String name = ent.getName();
                if (ent instanceof EntityPlayer) {
                    double diffH;
                    double diffZ;
                    double diffX;
                    List<EntityPlayer> list;
                    double diffY;
                    String formated = ent.getDisplayName().getFormattedText();
                    if (format.startsWith("\u00a7c\u00a7c") && !custom.equals("  ") && name.contains("\u00a7c")) {
                        Minecraft.theWorld.removeEntity(ent);
                        Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Removed an bot");
                        if (!invaild.contains(ent)) {
                            Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Detect a new type of bot");
                            invaild.add(ent);
                        }
                    }
                    if (ent.isInvisible() && !formated.startsWith("\u00a7c") && formated.endsWith("\u00a7r") && custom.equals(name)) {
                        diffX = Math.abs(ent.posX - Minecraft.thePlayer.posX);
                        diffY = Math.abs(ent.posY - Minecraft.thePlayer.posY);
                        diffZ = Math.abs(ent.posZ - Minecraft.thePlayer.posZ);
                        diffH = Math.sqrt(diffX * diffX + diffZ * diffZ);
                        if (diffY < 13.0 && diffY > 10.0 && diffH < 3.0 && !(list = AntiBot.getTabPlayerList()).contains(ent)) {
                            Minecraft.theWorld.removeEntity(ent);
                            Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Removed an bot");
                            invaild.add(ent);
                        }
                    }
                    if (!formated.startsWith("\u00a7") && formated.endsWith("\u00a7r")) {
                        invaild.add(ent);
                    }
                    if (ent.isInvisible() && !custom.equalsIgnoreCase("") && custom.toLowerCase().contains("\u00a7c\u00a7c") && name.contains("\u00a7c")) {
                        Minecraft.theWorld.removeEntity(ent);
                        Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Removed an bot");
                        invaild.add(ent);
                    }
                    if (!custom.equalsIgnoreCase("") && custom.toLowerCase().contains("\u00a7c") && custom.toLowerCase().contains("\u00a7r")) {
                        Minecraft.theWorld.removeEntity(ent);
                        Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Removed an bot");
                        invaild.add(ent);
                    }
                    if (formated.contains("\u00a78[NPC]")) {
                        invaild.add(ent);
                    }
                    if (!formated.contains("\u00a7c") && !custom.equalsIgnoreCase("")) {
                        invaild.add(ent);
                    }
                    if (format.contains("[NPC") && !invaild.contains(ent)) {
                        invaild.add(ent);
                    }
                    if (format.contains("[NPC]") && !invaild.contains(ent)) {
                        invaild.add(ent);
                    }
                    if (ent.isInvisible() && !custom.equalsIgnoreCase("") && custom.toLowerCase().contains("\u6402c\u6402c") && name.contains("\u6402c") && !invaild.contains(ent)) {
                        invaild.add(ent);
                    }
                    if (!format.startsWith("\u6402") && format.endsWith("\u6402r")) {
                        invaild.add(ent);
                    }
                    if (!custom.equalsIgnoreCase("") && custom.toLowerCase().contains("\u6402c") && custom.toLowerCase().contains("\u6402r") && !invaild.contains(ent)) {
                        invaild.add(ent);
                    }
                    if (ent.isInvisible() && !format.startsWith("\u6402c") && format.endsWith("\u6402r") && custom.equals(name)) {
                        diffX = Math.abs(ent.posX - Minecraft.thePlayer.posX);
                        diffY = Math.abs(ent.posY - Minecraft.thePlayer.posY);
                        diffZ = Math.abs(ent.posZ - Minecraft.thePlayer.posZ);
                        diffH = Math.sqrt(diffX * diffX + diffZ * diffZ);
                        if (diffY < 13.0 && diffY > 10.0 && diffH < 3.0 && !(list = AntiBot.getTabPlayerList()).contains(ent) && !invaild.contains(ent)) {
                            invaild.add(ent);
                        }
                    }
                    if (format.contains("[NPC]") && format.startsWith(EnumChatFormatting.RED.toString())) {
                        Minecraft.theWorld.removeEntity(ent);
                        Helper.sendMessage((Object)((Object)EnumChatFormatting.RED) + "Removed an bot");
                        if (!invaild.contains(ent)) {
                            invaild.add(ent);
                        }
                    }
                    if (format.contains("\u64028[NPC]") && !invaild.contains(ent)) {
                        invaild.add(ent);
                    }
                    if (!(format.contains("\u6402c") || custom.equalsIgnoreCase("") || invaild.contains(ent))) {
                        invaild.add(ent);
                    }
                }
                if (format.contains("\u64028[NPC]") && !invaild.contains(ent)) {
                    invaild.add(ent);
                }
                if (!(format.contains("\u6402c") || custom.equalsIgnoreCase("") || invaild.contains(ent))) {
                    invaild.add(ent);
                }
            }
            if (!(o instanceof EntityArmorStand) || !((ent = (EntityArmorStand)o) instanceof EntityArmorStand) || invaild.contains(ent)) continue;
            invaild.add(ent);
        }
    }

    public static List<EntityPlayer> getTabPlayerList() {
        Minecraft.getMinecraft();
        NetHandlerPlayClient var4 = Minecraft.thePlayer.sendQueue;
        ArrayList<EntityPlayer> list = new ArrayList<EntityPlayer>();
        List players = GuiPlayerTabOverlay.field_175252_a.sortedCopy(var4.getPlayerInfoMap());
        for (Object o : players) {
            NetworkPlayerInfo info = (NetworkPlayerInfo)o;
            if (info == null) continue;
            Minecraft.getMinecraft();
            list.add(Minecraft.theWorld.getPlayerEntityByName(info.getGameProfile().getName()));
        }
        return list;
    }

    public boolean isServerBot(Entity entity) {
        return invaild.contains(entity);
    }

    public static List<Entity> getBots() {
        return invaild;
    }
}

