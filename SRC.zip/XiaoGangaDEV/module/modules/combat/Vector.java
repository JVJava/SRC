/*
 * Decompiled with CFR 0_132 Helper by Lightcolour E-mail wyy-666@hotmail.com.
 */
package com.XiaoGangaDEV.module.modules.combat;

public class Vector<T extends Number> {
    private T x;
    private T y;
    private T z;

    public Vector(T x, T y, T z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Vector setX(T x) {
        this.x = x;
        return this;
    }

    public Vector setY(T y) {
        this.y = y;
        return this;
    }

    public Vector setZ(T z) {
        this.z = z;
        return this;
    }

    public T getX() {
        return this.x;
    }

    public T getY() {
        return this.y;
    }

    public T getZ() {
        return this.z;
    }
}

