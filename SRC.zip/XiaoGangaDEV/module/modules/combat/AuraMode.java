package com.XiaoGangaDEV.module.modules.combat;

enum AuraMode {
   Switch;
}
