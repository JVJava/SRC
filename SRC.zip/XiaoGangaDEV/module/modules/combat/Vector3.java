/*
 * Decompiled with CFR 0_132 Helper by Lightcolour E-mail wyy-666@hotmail.com.
 */
package com.XiaoGangaDEV.module.modules.combat;

public class Vector3<T extends Number>
extends Vector<Number> {
    public Vector3(T x, T y, T z) {
        super(x, y, z);
    }

    public Vector2<Float> toVector2() {
        return new Vector2<Float>(this.getX(), (Float)this.getY());
    }

    @Override
    public Float getX() {
        return null;
    }
}

