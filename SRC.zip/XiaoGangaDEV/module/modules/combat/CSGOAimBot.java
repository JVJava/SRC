/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.module.modules.combat;

import com.XiaoGangaDEV.api.EventHandler;
import com.XiaoGangaDEV.api.events.world.EventPreUpdate;
import com.XiaoGangaDEV.api.value.Option;
import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.ModuleType;
import com.XiaoGangaDEV.utils.Helper;
import com.XiaoGangaDEV.utils.math.RotationUtil;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

import org.lwjgl.input.Mouse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.FoodStats;
import net.minecraft.util.MathHelper;

public class CSGOAimBot
extends Module {
    public static ArrayList faceTarget = new ArrayList();
    public CSGOAimBot() {
        super("CSGOAimbot", new String[]{"CSAimbot"}, ModuleType.Combat);
        this.setColor(new Color(158, 205, 125).getRGB());
    }

    @EventHandler
    private void onUpdate(EventPreUpdate event) {
    	if(Mouse.isButtonDown(1)) {
    		
    	}
    }

}

