/*
 * Decompiled with CFR 0.148.
 */
package com.XiaoGangaDEV.module.modules.combat;

public class Timer {
    static long prevMS;
    private long time;
    protected static long lastMS;
    private long lastMS1;

    public Timer() {
        prevMS = 0L;
        lastMS = -1L;
        this.time = System.nanoTime() / 1000000L;
    }

    public static boolean delay(float milliSec) {
        return (float)(Timer.getTime() - prevMS) >= milliSec;
    }

    public static boolean delay(double milliSec) {
        return (double)(Timer.getTime() - prevMS) >= milliSec;
    }

    public boolean check(float milliseconds) {
        return (float)Timer.getTime() >= milliseconds;
    }

    public boolean delay1(float milliSec) {
        return (float)(Timer.getTime() - prevMS) >= milliSec;
    }

    public void reset1() {
        this.lastMS1 = Timer.getCurrentMS();
    }

    public static void reset() {
        prevMS = Timer.getTime();
    }

    public static long getTime() {
        return System.nanoTime() / 1000000L;
    }

    public long time() {
        return System.nanoTime() / 1000000L - this.time;
    }

    public long getDifference() {
        return Timer.getTime() - prevMS;
    }

    public void setDifference(long difference) {
        prevMS = Timer.getTime() - difference;
    }

    public boolean hasTimeElapsed(long time, boolean reset) {
        if (this.time() >= time) {
            if (reset) {
                Timer.reset();
            }
            return true;
        }
        return false;
    }

    public void setLastMS() {
        lastMS = System.currentTimeMillis();
    }

    public boolean isDelayComplete(long delay) {
        return System.currentTimeMillis() - lastMS >= delay;
    }

    public long getLastMs() {
        return System.currentTimeMillis() - lastMS;
    }

    public static long getCurrentMS() {
        return System.nanoTime() / 1000000L;
    }

    public long getLastMS() {
        return lastMS;
    }

    public static boolean hasReached(long milliseconds) {
        return Timer.getCurrentMS() - lastMS >= milliseconds;
    }

    public void setLastMS(long currentMS) {
        lastMS = currentMS;
    }

    public boolean hasReached(double milliseconds) {
        return (double)(Timer.getCurrentMS() - lastMS) >= milliseconds;
    }

    public boolean hasTicksElapsed(int ticks) {
        return this.time() >= (long)(1000 / ticks - 50);
    }

    public boolean hasTicksElapsed(int time, int ticks) {
        return this.time() >= (long)(time / ticks - 50);
    }
}

