/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.value;

import com.XiaoGangaDEV.api.value.Value;

public class Option<V>
extends Value<V> {
    public Option(String displayName, String name, V enabled) {
        super(displayName, name);
        this.setValue(enabled);
    }


}

