package com.XiaoGangaDEV.api;

import com.darkmagician6.eventapi.events.Event;

public class EventPostMotion implements Event {}
