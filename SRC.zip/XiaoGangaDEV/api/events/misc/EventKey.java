/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.events.misc;

import com.XiaoGangaDEV.api.Event;

public class EventKey
extends Event {
    private int key;

    public EventKey(int key) {
        this.key = key;
    }

    public int getKey() {
        return this.key;
    }

    public void setKey(int key) {
        this.key = key;
    }
}

