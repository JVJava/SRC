/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.events.world;

import java.util.Random;

import com.XiaoGangaDEV.api.Event;

import net.minecraft.client.Minecraft;

public class EventPreUpdate
extends Event {
    private float yaw;
    private float pitch;
    public double y;
    private boolean ground;
    private static final Random random = new Random();

    public EventPreUpdate(float yaw, float pitch, double y, boolean ground) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.y = y;
        this.ground = ground;
    }

    public float getYaw() {
        return this.yaw;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getPitch() {
        return this.pitch;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public double getY() {
        return this.y;
    }

    public void setY(double y) {
        this.y = y;
    }

    public boolean isOnground() {
        return this.ground;
    }

    public void setOnground(boolean ground) {
        this.ground = ground;
    }

    public void setRotations(float[] rotations, boolean random) {
        if (random) {
            this.yaw = rotations[0] + (float)(EventPreUpdate.random.nextBoolean() ? Math.random() : - Math.random());
            this.pitch = rotations[1] + (float)(EventPreUpdate.random.nextBoolean() ? Math.random() : - Math.random());
        } else {
            this.yaw = rotations[0];
            this.pitch = rotations[1];
        }
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationYawHead = this.yaw;
        Minecraft.getMinecraft();
        Minecraft.thePlayer.renderYawOffset = this.yaw;
        Minecraft.getMinecraft();
        Minecraft.thePlayer.rotationPitchHead = this.pitch;
    }
}

