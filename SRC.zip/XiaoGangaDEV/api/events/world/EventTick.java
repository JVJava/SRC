/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.events.world;

import com.XiaoGangaDEV.api.Event;

public class EventTick
extends Event {
}

