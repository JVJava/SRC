/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.events.world;

import com.XiaoGangaDEV.api.Event;
import net.minecraft.network.Packet;

public class EventPacketSend
extends Event {
    private static Packet packet;

    public EventPacketSend(Packet packet) {
        this.packet = packet;
    }

    public static Packet getPacket() {
        return packet;
    }

    public void setPacket(Packet packet) {
        this.packet = packet;
    }
}

