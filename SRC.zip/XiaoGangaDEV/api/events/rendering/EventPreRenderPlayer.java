/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.api.events.rendering;

import com.XiaoGangaDEV.api.Event;

public class EventPreRenderPlayer
extends Event {
}

