/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV;

import com.XiaoGangaDEV.api.value.Value;
import com.XiaoGangaDEV.management.CommandManager;
import com.XiaoGangaDEV.management.FileManager;
import com.XiaoGangaDEV.management.FriendManager;
import com.XiaoGangaDEV.management.ModuleManager;
import com.XiaoGangaDEV.module.Module;
import com.XiaoGangaDEV.module.modules.render.UI.TabUI;
import com.XiaoGangaDEV.ui.login.AltManager;
import java.io.PrintStream;
import java.time.OffsetDateTime;
import java.util.List;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;

public class Client {
    public static String name = "Core";
    public final static double version = 1.0;
    public static boolean publicMode = false;
    public static Client instance = new Client();
    private static ModuleManager modulemanager;
    private CommandManager commandmanager;
    private AltManager altmanager;
    private FriendManager friendmanager;
    private TabUI tabui;
    public static ResourceLocation CLIENT_CAPE = new ResourceLocation("Core/cape.png");
	public static int lastVer;
	public static String lastName;
	public static boolean paiduser;

    public void initiate() {
        this.commandmanager = new CommandManager();
        this.commandmanager.init();
        this.friendmanager = new FriendManager();
        this.friendmanager.init();
        this.modulemanager = new ModuleManager();
        this.modulemanager.init();
        this.tabui = new TabUI();
        this.tabui.init();
        this.altmanager = new AltManager();
        AltManager.init();
        AltManager.setupAlts();
        FileManager.init();
    }

    public static ModuleManager getModuleManager() {
        return modulemanager;
    }

    public CommandManager getCommandManager() {
        return this.commandmanager;
    }

    public AltManager getAltManager() {
        return this.altmanager;
    }

    public void shutDown() {
        String values = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            for (Value v : m.getValues()) {
                values = String.valueOf(values) + String.format("%s:%s:%s%s", m.getName(), v.getName(), v.getValue(), System.lineSeparator());
            }
        }
        FileManager.save("Values.txt", values, false);
        String enabled = "";
        instance.getModuleManager();
        for (Module m : ModuleManager.getModules()) {
            if (!m.isEnabled()) continue;
            enabled = String.valueOf(enabled) + String.format("%s%s", m.getName(), System.lineSeparator());
        }
        FileManager.save("Enabled.txt", enabled, false);
    }

    public static void RenderRotate(float yaw) {
        Minecraft.thePlayer.renderYawOffset = yaw;
        Minecraft.thePlayer.rotationYawHead = yaw;
     }
}

