package com.XiaoGangaDEV.utils;

public enum FlatColors {
	TURKIS(-15024996),
	BLACK(-16711423),
    GREEN(-13710223),
    BLUE(-13330213),
    PURPLE(-6596170),
    ASPHALT(-13350562),
    YELLOW(-932849),
    ORANGE(-812014),
    RED(-1618884),
    WHITE(-1249039),
    SILVER(-4340793),
    DARK_BLUE(-14057287),
    DARK_GREEN(-14176672),
    DARK_TURKIS(-15294331),
    DARK_PURPLE(-7453523),
    DARK_ASPHALT(-13877680),
    DARK_ORANGE_ONE(-1671646),
    DARK_ORANGE_TWO(-2927616),
    GREY(-6969946),
    DARK_RED(-4179669),
    DARK_GREY(-8418163);
    
    public int c;

    private FlatColors(int co) {
        this.c = co;
    }
}
