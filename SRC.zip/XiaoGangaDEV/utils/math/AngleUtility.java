/*
 * Decompiled with CFR 0_132 Helper by Lightcolour E-mail wyy-666@hotmail.com.
 */
package com.XiaoGangaDEV.utils.math;

import java.util.Random;

import com.XiaoGangaDEV.api.Event;
import com.XiaoGangaDEV.module.modules.combat.Vector3;

import com.XiaoGangaDEV.module.modules.combat.KillAura;
import net.minecraft.client.Minecraft;
import net.minecraft.util.BlockPos;

public class AngleUtility
extends Event {
    private static float minYawSmoothing;
    private static float maxYawSmoothing;
    private static float minPitchSmoothing;
    private static float maxPitchSmoothing;
    private static Vector3<Float> delta;
    private static Angle smoothedAngle;
    private static Random random;
    private static float height;

    static {
        height = 1.5f;
    }

    public AngleUtility(float minYawSmoothing, float maxYawSmoothing, float minPitchSmoothing, float maxPitchSmoothing) {
        AngleUtility.minYawSmoothing = minYawSmoothing;
        AngleUtility.maxYawSmoothing = maxYawSmoothing;
        AngleUtility.minPitchSmoothing = minPitchSmoothing;
        AngleUtility.maxPitchSmoothing = maxPitchSmoothing;
        random = new Random();
        delta = new Vector3<Float>(Float.valueOf(0.0f), Float.valueOf(0.0f), Float.valueOf(0.0f));
        smoothedAngle = new Angle(Float.valueOf(0.0f), Float.valueOf(0.0f));
    }

    public static float[] getAngleBlockpos(BlockPos target) {
        Minecraft.getMinecraft();
        double xDiff = (double)target.getX() - Minecraft.thePlayer.posX;
        Minecraft.getMinecraft();
        double yDiff = (double)target.getY() - Minecraft.thePlayer.posY;
        Minecraft.getMinecraft();
        double zDiff = (double)target.getZ() - Minecraft.thePlayer.posZ;
        float yaw = (float)(Math.atan2(zDiff, xDiff) * 180.0 / 3.141592653589793) - 90.0f;
        Minecraft.getMinecraft();
        Minecraft.getMinecraft();
        float pitch = (float)((- Math.atan2((double)target.getY() + -1.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
        if (yDiff > -0.2 && yDiff < 0.2) {
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            pitch = (float)((- Math.atan2((double)target.getY() + -1.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
        } else if (yDiff > -0.2) {
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            pitch = (float)((- Math.atan2((double)target.getY() + -1.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
        } else if (yDiff < 0.3) {
            Minecraft.getMinecraft();
            Minecraft.getMinecraft();
            pitch = (float)((- Math.atan2((double)target.getY() + -1.0 - (Minecraft.thePlayer.posY + (double)Minecraft.thePlayer.getEyeHeight()), Math.hypot(xDiff, zDiff))) * 180.0 / 3.141592653589793);
        }
        return new float[]{yaw, pitch};
    }

    public float randomFloat(float min, float max) {
        return min + random.nextFloat() * (max - min);
    }

    public Angle calculateAngle(Vector3<Double> destination, Vector3<Double> source) {
        Angle angles = new Angle(Float.valueOf(0.0f), Float.valueOf(0.0f));
        float height2 = 1.2f;
        delta.setX(Float.valueOf(destination.getX().floatValue() - source.getX().floatValue())).setY(Float.valueOf(destination.getY().floatValue() + height2 - (source.getY().floatValue() + height2))).setZ(Float.valueOf(destination.getZ().floatValue() - source.getZ().floatValue()));
        double hypotenuse = Math.hypot(delta.getX().doubleValue(), delta.getZ().doubleValue());
        float yawAtan = (float)Math.atan2(delta.getZ().floatValue(), delta.getX().floatValue());
        float pitchAtan = (float)Math.atan2(delta.getY().floatValue(), hypotenuse);
        float deg = 57.29578f;
        float yaw = yawAtan * deg - 90.0f;
        float pitch = - pitchAtan * deg;
		return angles;

    }

    public Angle smoothAngle(Angle destination, Angle source) {
		return source;   }
}

