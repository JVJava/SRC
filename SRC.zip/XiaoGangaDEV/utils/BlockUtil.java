/*
 * Decompiled with CFR 0_132.
 */
package com.XiaoGangaDEV.utils;

public class BlockUtil {
}

